EUI.BrandView = EUI.extend(EUI.CustomUI, {
    renderTo: "",
    brandId: "",
    currentBrandHasClassify: "",
    initComponent: function () {
        EUI.Container({
            renderTo: this.renderTo,
            layout: "border",
            // border: false,
            itemspace: 0,
            padding: 8,
            isOverFlow: false,
            html: "<div id='brand_classify' style='display:block;'>"
        });
        this.initFirst();
        this.initEvents();
    },
    initFirst: function () {
        var g = this;
        EUI.Container({
            region: "center",
            layout: "border",
            renderTo: "brand_classify",
            border: false,
            padding: 3,
            itemspace: 2,
            isOverFlow: false,
            items: [this.initWestContainer(), this.initCenterContainer()]
        });
    },
    initWestContainer: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "west",
            padding: 1,
            width: 530,
            itemspace: 0,
            layout: "border",
            border: false,
            items: [{
                xtype: "Container",
                region: "north",
                border: false,
                height: 40,
                padding: 0,
                layout: "border",
                items: [this.leftBar()]
            }, this.leftGrid()]

        }
    },
    leftBar: function () {
        var g = this;
        return {
            xtype: "ToolBar",
            region: "center",
            isOverFlow: false,
            padding: 0,
            border: false,
            // defaultConfig: {
            //     style: {
            //         "margin": "auto",
            //     }
            // },
            items: [{
                xtype: "Button",
                title: "新增",
                id: "addGroup",
                selected: true,
                handler: function () {
                    g.AddBrandWind();
                }
            }, '->', {
                xtype: "SearchBox",
                width: 250,
                displayText: "请输入代码或描述进行搜索",
                onSearch: function (v) {
                    EUI.getCmp("brandPanel").localSearch(v);
                },
                afterClear: function () {
                    EUI.getCmp("brandPanel").localSearch();
                }
            }]
        }
    },
    leftGrid: function ()  {
        var g = this;
        return {
            xtype: "GridPanel",
            region: "center",
            id: "brandPanel",
            searchConfig: {
                searchCols: ["code", "content"]
            },
            gridCfg: {
                caption: "产品品牌",
                loadonce: true,
                url: _ctxPath + "/basic/brand/listAllBrand",
                // params: {
                //     name: ""
                // },
                //datatype: "local",
                colModel: [
                    {
                        label: "操作",
                        name: "operate",
                        index: "operate",
                        width: 90,
                        align: "center",
                        formatter: function (cellvalue, options, rowObject) {
                            var strVar = "<div class='condetail_operate'>"
                                + "<div class='condetail_update'></div>"
                                + "<div class='condetail_delete'></div></div>";
                            return strVar;
                        }
                    }, {name: 'id', hidden: true},
                    {name: 'code', index: 'code', sortable: true, width: 120, label: "代码"},
                    {name: 'content', index: 'content', width: 150, label: "描述"}
                ],
                rowNum: 15,
                shrinkToFit: false,
                sortname: 'code',
                sortorder: "asc",
                onSelectRow: function () {
                    var selectRow = EUI.getCmp("brandPanel").getSelectRow();
                    g.brandId = selectRow.id;
                    g.getHasClassifyByBrandId(selectRow.id)
                }
            }
        }
    },
    getHasClassifyByBrandId: function (brandId) {
        var g = this;
        // var mask = EUI.LoadMask({
        //     msg: "正在加载中..."
        // });
        EUI.Store({
            url: _ctxPath + "/basic/brandProductCategories/listHasProductCategoriesByBrandId",
            params: {brandId: brandId},
            success: function (result) {
                // mask.hide();
                g.currentBrandHasClassify = result;
                g.getAllClassifyData();
            },
            failure: function (result) {
                // mask.hide();
            }
        });
    },
    getAllClassifyData: function () {
        var g = this;
        // var mask = EUI.LoadMask({
        //     msg: "正在加载中..."
        // });
        EUI.Store({
            url: _ctxPath + "/basic/productCategories/listFindAllProductCategories",
            success: function (result) {
                // mask.hide();
                EUI.getCmp("classifyGrid").setDataInGrid(result);
                g.setHaveDataInGrid(result);
            },
            failure: function (result) {
                // mask.hide();
            }
        });
    },
    initCenterContainer: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "center",
            layout: "border",
            border: false,
            padding: 1,
            itemspace: 0,
            // style: {
            //     // "border-left": "0px",
            //     "padding-left": "10px"
            // },
            items: [{
                xtype: "Container",
                region: "north",
                border: false,
                itemspace: 0,
                height: 40,
                padding: 0,
                layout: "border",
                items: [this.rightBar()]
            }, this.rightGrid(), this.rightButton()]
        }
    },
    rightBar: function () {
        var g = this;
        return {
            xtype: "ToolBar",
            region: "center",
            isOverFlow: false,
            padding: 0,
            border: false,
            // defaultConfig: {
            //     style: {
            //         "margin": "auto",
            //     }
            // },
            items: [/*{
             xtype: "Button",
             title: "新增",
             id: "addClassify",
             selected: true,
             handler: function () {
             }
             }, '->', {
             xtype: "SearchBox",
             width:300,
             displayText: "请输入名称进行搜索",
             onSearch: function (v) {
             if (!v) {
             EUI.getCmp("classifyGrid").setPostParams({
             Q_LK_code: ""
             }
             ).trigger("reloadGrid");
             }
             EUI.getCmp("classifyGrid").setPostParams({
             Q_LK_code:v
             }
             ).trigger("reloadGrid");
             }
             }*/]
        }
    },
    rightGrid: function () {
        var g = this;
        return {
            xtype: "GridPanel",
            id: "classifyGrid",
            region: "center",
            width: 400,
            height: '100%',
            style: {
                "border-radius": "3px"
            },
            gridCfg: {
                caption: "产品大类",
                datatype: "local",
                loadonce: true,
                multiselect: true,
                hasPager: false,
                colModel: [
                    {name: 'id', hidden: true},
                    {name: 'code', index: 'code', width: 120, label: "代码"},
                    {name: 'content', index: 'content', width: 120, label: "描述"}
                ],
                rowNum: 100,
                shrinkToFit: false
            }
        }
    },
    rightButton: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "south",
            height: 50,
            // width: 450,
            border: false,
            items: [{
                xtype: "Button",
                title: "保存",
                width: 100,
                selected: true,
                style: {
                    "margin-top": "10px",
                    "margin-left":"48%"
                },
                handler: function () {
                    if (!g.brandId) {
                        var status = {
                            msg: "请选择产品品牌",
                            success: false,
                            showTime: 4
                        };
                        EUI.ProcessStatus(status);
                        return;
                    }
                    var selectDatas = EUI.getCmp("classifyGrid").getSelectRow();
                    var chooseSkillIds = "";
                    for (var i = 0; i < selectDatas.length; i++) {
                        chooseSkillIds += selectDatas[i].id + ",";
                    }
                    chooseSkillIds = (chooseSkillIds.substring(chooseSkillIds.length - 1) == ',') ? chooseSkillIds.substring(0, chooseSkillIds.length - 1) : chooseSkillIds;
                    var myMask = EUI.LoadMask({
                        msg: "正在保存，请稍候..."
                    });
                    EUI.Store({
                        url: _ctxPath + "/basic/brandProductCategories/saveChooseProductCategories",
                        params: {
                            brandId: g.brandId,
                            chooseSkillIds: chooseSkillIds
                        },
                        success: function (status) {
                            myMask.hide();
                            EUI.ProcessStatus(status);
                        },
                        failure: function (status) {
                            myMask.hide();
                            EUI.ProcessStatus(status);
                        }
                    });
                }
            }]
        }
    },
    setHaveDataInGrid: function (allData) {
        var g = this;
        var hasData = this.currentBrandHasClassify;
        for (var i = 0; i < hasData.length; i++) {
            if (this.itemIdIsInArray(hasData[i].child.id, allData)) {
                EUI.getCmp("classifyGrid").setSelectRowById(hasData[i].child.id);
            }
        }
    },
    itemIdIsInArray: function (id, array) {
        for (var i = 0; i < array.length; i++) {
            if (id == array[i].id) {
                return true;
            }
        }
        return false;
    },
    initEvents: function () {
        var g = this;
        $(".condetail_update").live("click", function () {
            var data = EUI.getCmp("brandPanel").getSelectRow();
            g.updateBrand(data);
            EUI.getCmp("updateBrand").loadData(data)
        });
        $(".condetail_delete").live("click", function () {
            var selectRow = EUI.getCmp("brandPanel").getSelectRow();
            g.deleteBrand(selectRow.id);
        });
    },
    message: function (msg) {
        var g = this;
        var message = EUI.MessageBox({
            border: true,
            //hintText: "提示",
            title: "提示",
            showClose: true,
            msg: msg,
            buttons: [{
                //okText:"确定",
                title: "确定",
                handler: function () {
                    message.remove();
                }
            }]
        });
    },
    AddBrandWind: function () {
        var g = this;
        var win = EUI.Window({
            title: "新增产品品牌",
            height: 70,
            width: 328,
            padding: 15,
            items: [{
                xtype: "FormPanel",
                id: "addBrand",
                padding: 0,
                items: [{
                    xtype: "TextField",
                    title: "代码",
                    labelWidth: 56,
                    allowBlank: false,
                    name: "code",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "描述",
                    labelWidth: 56,
                    allowBlank: false,
                    name: "content",
                    width: 266
                }/*, {
                 xtype: "TextField",
                 title: "排序码",
                 labelWidth: 90,
                 name: "rank",
                 width: 220
                 }*/]
            }],
            buttons: [{
                title: "保存",
                selected: true,
                handler: function () {
                    var form = EUI.getCmp("addBrand");
                    if (!form.isValid()) {
                        return;
                    }
                    var data = form.getFormValue();
                    g.saveBrand(data, win);
                }
            }, {
                title: "取消",
                handler: function () {
                    win.remove();
                }
            }]
        });
    },
    saveBrand: function (data, win) {
        var g = this;
        var myMask = EUI.LoadMask({
            msg: "正在保存，请稍候..."
        });
        EUI.Store({
            url: _ctxPath + "/basic/brand/save",
            params: data,
            success: function (result) {
                myMask.hide();
                EUI.ProcessStatus(result);
                if (result.success) {
                    EUI.getCmp("brandPanel").refreshGrid();
                    win.remove();
                }
            },
            failure: function (result) {
                EUI.ProcessStatus(result);
                myMask.hide();
            }
        });
    },
    deleteBrand: function (id) {
        var g = this;
        var infoBox = EUI.MessageBox({
            title: "提示",
            msg: "确定删除吗？",
            buttons: [{
                title: "确定",
                selected: true,
                handler: function () {
                    infoBox.remove();
                    var myMask = EUI.LoadMask({
                        msg: "正在删除,请稍后...."
                    });
                    EUI.Store({
                        url: _ctxPath + "/basic/brand/deleteBrand",
                        params: {
                            id: id
                        },
                        success: function (result) {
                            myMask.hide();
                            EUI.ProcessStatus(result);
                            if (result.success) {
                                EUI.getCmp("brandPanel").refreshGrid();
                            }
                        },
                        failure: function (result) {
                            EUI.ProcessStatus(result);
                            myMask.hide();
                        }
                    });
                }
            }, {
                title: "取消",
                handler: function () {
                    infoBox.remove();
                }
            }]
        });
    },
    updateBrand: function () {
        var g = this;
        var win = EUI.Window({
            title: "修改产品品牌",
            height: 70,
            width: 326,
            padding: 15,
            items: [{
                xtype: "FormPanel",
                id: "updateBrand",
                padding: 0,
                items: [{
                    xtype: "TextField",
                    title: "ID",
                    labelWidth: 56,
                    allowBlank: false,
                    name: "id",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "代码",
                    labelWidth: 56,
                    allowBlank: false,
                    name: "code",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "描述",
                    labelWidth: 56,
                    allowBlank: false,
                    name: "content",
                    width: 266
                }]
            }],
            buttons: [{
                title: "保存",
                selected: true,
                handler: function () {
                    var form = EUI.getCmp("updateBrand");
                    if (!form.isValid()) {
                        return;
                    }
                    var data = form.getFormValue();
                    g.saveBrand(data, win);
                }
            }, {
                title: "取消",
                handler: function () {
                    win.remove();
                }
            }]
        });
    }
});