EUI.BasicDataIndexView = EUI.extend(EUI.CustomUI, {
    renderTo: "",
    isEdit: false,
    selectedNode: null,
    initComponent: function () {
        EUI.Container({
            renderTo: this.renderTo,
            layout: "border",
            border: false,
            padding: 8,
            itemspace: 2,
            items: [this.initLeft(), this.initMain()]
        });
        var nodePath;
        var tree;
        this.treeCmp = EUI.getCmp("treePanel");
        this.editFormCmp = EUI.getCmp("editForm");
        this.getMenuTreeData();
    },
    initLeft: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "west",
            border: false,
            width: 450,
            itemspace: 0,
            padding: 1,
            layout: "border",
            items: [this.initTopBar(), this.initTree() /*this.initBottomBar()*/]
        }
    },
    initTopBar: function () {
        var g = this;
        return {
            xtype: "ToolBar",
            region: "north",
            height: 40,
            isOverFlow: false,
            border: false,
            padding:0,
            items: [{
                xtype: "Button",
                //createNodeText:创建根节点
                title: "创建根节点",
                selected: true,
                style:{
                    "margin-right":"-5px"
                },
                handler: function () {
                    g.isEdit = false;
                    g.addRootNode();
                }
            }, {
                xtype: "Button",
                //createNodeText:创建节点
                title:"创建节点",
                style:{
                    "margin-right":"-5px"
                },
                handler: function () {
                    if (!g.selectedNode) {
                        //addHintMessageText: 请选择一个菜单节点
                        g.message("请选择一个菜单节点");
                        return false;
                    }
                    if (g.selectedNode.nodeLevel == 1 && g.selectedNode.feature != null) {
                        g.message("已经绑定功能项，不能创建子节点！");
                        return false;
                    }
                    if (g.selectedNode.nodeLevel == 2) {
                        g.message("最后一层，不能再创建子节点！");
                        return false;
                    }
                    g.isEdit = false;
                    g.addNode();
                }
            }, /*{
                xtype: "Button",
                //moveText: 移动
                title: g.lang.moveText?g.lang.moveText:"移动",
                style:{
                    "margin-right":"-5px"
                },
                handler: function () {
                    if (!g.selectedNode) {
                        //addHintMessageText: 请选择一个菜单节点
                        g.message(g.lang.addHintMessageText?g.lang.addHintMessageText:"请选择一个菜单节点");
                        return false;
                    } else {
                        if (g.selectedNode.nodeLevel==0) {
                            g.message(g.lang.noSelectRootText?g.lang.noSelectRootText:"");
                            return false;
                        } else {
                            var node = g.selectedNode;
                            if (node.id) {
                                g.treeCmp.setSelect(node.id);
                            }
                            var selData = g.treeCmp.getNodeData(node.id);
                            if (selData) {
                                g.openNodeMoveWin(selData);
                            }
                        }
                    }
                }
            },*/ {
                xtype: "Button",
                //deleteText: 删除
                title: "删除",
                style:{
                    "margin-right":"-5px"
                },
                handler: function () {
                    if (!g.selectedNode) {
                        //addHintMessageText: 请选择一个菜单节点
                        g.message("请选择一个菜单节点");
                        return false;
                    }
                    g.isEdit = false;
                    if (g.selectedNode.nodeLevel==0) {
                        g.deleteRootNode(g.selectedNode);
                    } else {
                        g.deleteTreeNode(g.selectedNode);
                    }
                }
            },'->', {
                xtype: "SearchBox",
                canClear: true,
                width:165,
                closable: false,
                id: "searchBox_treePanel",
                //searchBoxDisplayText: 请输入名字查询...
                displayText:"请输入名字查询",
                onSearch: function (value) {
                    g.treeCmp.search(value);
                },
                afterClear: function () {
                    g.treeCmp.reset();
                }}]
        };
    },
    initTree: function () {
        var g = this;
        return {
            xtype: "TreePanel",
            region: "center",
            border: true,
            style:{
                "background":"#fff"
            },
            // searchField: ["name"],
            id: "treePanel",
            showField: "name",
            onSelect: function (node) {
                var myMask = EUI.LoadMask({
                    //queryMaskMessageText: "正在努力获取数据，请稍候...",
                    msg: "正在努力获取数据，请稍候..."
                });
                EUI.Store({
                    url: _ctxPath + "/basic/data/getBasicData",
                    params: {
                        id: node.id
                    },
                    success: function (result) {
                        myMask.hide();
                        var t_node = result.data;
                        g.selectedNode = t_node;
                        g.editFormCmp.loadData(t_node);
                        if(g.selectedNode){
                            var path = t_node.namePath;
                            nodePath = path.substring(1);
                            $('.nodePath').text(nodePath);
                        }
                        if(t_node.feature!= null){
                            var appData = t_node.feature.featureGroup;
                            EUI.getCmp("choseFeatureGroup").loadData(appData);
                            EUI.getCmp("choseFeature").store.params={appId : appData.appModule.id};
                        }
                    },
                    failure: function (re) {
                        myMask.hide();
                        var status = {
                            msg: re.msg,
                            success: false,
                            showTime: 6
                        };
                        EUI.ProcessStatus(status);
                    }
                });

                if (node.nodeLevel==0) {
                    EUI.getCmp("choseFeature").hide();
                    EUI.getCmp("choseFeatureGroup").hide();
                } else {
                    if (node.children!=null && node.children.length > 0) {
                        EUI.getCmp("choseFeature").hide();
                        EUI.getCmp("choseFeatureGroup").hide();
                    } else {
                        EUI.getCmp("choseFeature").show();
                        EUI.getCmp("choseFeatureGroup").show();
                    }
                }
            }
        }
    },
    deleteRootNode: function (rowData) {
        var g = this;
        var infoBox = EUI.MessageBox({
            //hintText: 提示
            title: "提示",
            //deleteHintMessageText
            msg: "您确定要删除吗？",
            buttons: [{
                xtype: "Button",
                //okText: 确定
                title: "确定",
                selected: true,
                handler: function () {
                    infoBox.remove();
                    var myMask = EUI.LoadMask({
                        //deleteMaskMessageText: 正在删除，请稍候...
                        msg: "正在删除，请稍候..."
                    });
                    EUI.Store({
                        url: _ctxPath + "/basic/data/delete",
                        params: {
                            id: rowData.id
                        },
                        success: function (result) {
                            myMask.hide();
                            var status = {
                                msg: result.msg,
                                success: result.success,
                                showTime: result.success ? 2 : 60
                            };
                            if (status.success) {
                                g.treeCmp.deleteItem(rowData.id);
                                var treeData = g.treeCmp.data;
                                for (var i = 0; i < treeData.length; i++) {
                                    if (treeData[i].id == rowData.id) {
                                        treeData.splice(i, 1);
                                    }
                                    if (treeData.length == 0) {
                                        treeData = null;
                                        break;
                                    }
                                }
                                g.treeCmp.initTree();
                                g.selectedNode = null;
                                // g.getMenuTreeData();
                                g.editFormCmp.reset();
                                $('.nodePath').text("...");
                                tree = g.treeCmp.data;
                            }
                            EUI.ProcessStatus(status);
                        },
                        failure: function (re) {
                            myMask.hide();
                            var status = {
                                msg: re.msg,
                                success: false,
                                showTime: 6
                            };
                            EUI.ProcessStatus(status);
                        }
                    });
                }
            }, {
                //cancelText: 取消
                title: "取消",
                handler: function () {
                    infoBox.remove();
                }
            }]
        });
    },
    deleteTreeNode: function (rowData) {
        var g = this;
        var infoBox = EUI.MessageBox({
            //hintText: 提示
            title: "提示",
            //deleteHintMessageText
            msg: "您确定要删除吗？",
            buttons: [{
                xtype: "Button",
                //okText: 确定
                title:"确定",
                selected: true,
                handler: function () {
                    infoBox.remove();
                    var myMask = EUI.LoadMask({
                        //deleteMaskMessageText: 正在删除，请稍候...
                        msg: "正在删除，请稍候..."
                    });
                    EUI.Store({
                        url: _ctxPath + "/basic/data/delete",
                        params: {
                            id: rowData.id
                        },
                        success: function (result) {
                            myMask.hide();
                            var status = {
                                msg: result.msg,
                                success: result.success,
                                showTime: result.success ? 2 : 60
                            };
                            if (status.success) {
                                g.treeCmp.deleteItem(rowData.id);
                                var parentData = g.treeCmp.getParentData(rowData.id);
                                for (var i = 0; i < parentData.children.length; i++) {
                                    if (parentData.children[i].id == rowData.id) {
                                        parentData.children.splice(i, 1);
                                    }
                                    if (parentData.children.length == 0) {
                                        parentData.children = null;
                                        break;
                                    }
                                }
                                g.treeCmp.initTree();
                                // g.getMenuTreeData();
                                g.treeCmp.setSelect(parentData.id);
                                g.editFormCmp.reset();
                                g.editFormCmp.loadData(parentData);
                                tree = g.treeCmp.data;
                            }
                            EUI.ProcessStatus(status);
                        },
                        failure: function (re) {
                            myMask.hide();
                            var status = {
                                msg: re.msg,
                                success: false,
                                showTime: 6
                            };
                            EUI.ProcessStatus(status);
                        }
                    });
                }
            }, {
                //cancelText: 取消
                title: "取消",
                handler: function () {
                    infoBox.remove();
                }
            }]
        });
    },
    addRootNode: function () {
        var g = this;
        g.editWin = EUI.Window({
            //addText: 新增
            title: "新增",
            height: 110,
            padding: 20,
            width: 430,
            items: [{
                xtype: "FormPanel",
                id: "createRootForm",
                padding: 0,
                defaultConfig: {
                    labelWidth: 70,
                    width: 340
                },
                items: [{
                    xtype: "TextField",
                    hidden: true,
                    name: "id"
                }, {
                    xtype: "TextField",
                    //nameText: 名称
                    title: "名称",
                    name: "name",
                    maxlength: 20,
                    allowBlank: false
                }, {
                    xtype: "TextField",
                    title: "代码",
                    name: "code",
                    maxlength: 20,
                    allowBlank: false
                }, {
                    xtype: "TextField",
                    //rankText: 排序
                    title:"排序",
                    name: "rank",
                    allowBlank: false,
                    allowChar: "1234567890",
                    maxlength: 11,
                    minLengthText: "最大长度为11位",
                    validateText: "排序必须为正整数",
                    validater: function (value) {
                        if(value < 1) {
                            return false;
                        }
                        return true;
                    }
                }]
            }],
            buttons: [{
                //saveText: 保存
                title: "保存",
                selected: true,
                handler: function () {
                    g.saveRootNode();
                }
            }, {
                //cancleText: 取消
                title: "取消",
                handler: function () {
                    g.editWin.remove();
                }
            }]
        });
        g.createRootForm = EUI.getCmp("createRootForm");
    },
    saveRootNode: function () {
        var g = this, data;

        if (g.isEdit) {
            if (!g.editFormCmp.isValid()) {
                return;
            }
            data = g.editFormCmp.getFormValue();
            delete data.parentId;
        } else {
            if (!g.createRootForm.isValid()) {
                return;
            }
            data = g.createRootForm.getFormValue();
            delete data.id;
        }

        var myMask = EUI.LoadMask({
            //saveMaskMessageText: 正在保存，请稍候...
            msg: "正在保存，请稍候..."
        });
        EUI.Store({
            url: _ctxPath + "/basic/data/save",
            params: data,
            success: function (result) {
                myMask.hide();
                var status = {
                    msg: result.msg,
                    success: result.success,
                    showTime: result.success ? 2 : 60
                };
                if (status.success) {
                    if (!g.isEdit) {
                        g.editWin.remove();
                    }
                    g.treeCmp.data.push(result.data);
                    var nodeData = result.data;
                    g.treeCmp.initTree();
                    // g.getMenuTreeData();
                    g.treeCmp.setSelect(nodeData.id);
                    g.selectedNode = nodeData;
                    tree = g.treeCmp.data;
                }
                EUI.ProcessStatus(status);
            },
            failure: function (re) {
                myMask.hide();
                var status = {
                    msg: re.msg,
                    success: false,
                    showTime: 6
                };
                EUI.ProcessStatus(status);
            }
        });
    },
    addNode: function () {
        var g = this;
        g.editWin = EUI.Window({
            //addText: 新增
            title: "新增",
            height: 134,
            padding: 20,
            width: 318,
            items: [{
                xtype: "FormPanel",
                id: "createForm",
                padding: 0,
                defaultConfig: {
                    labelWidth: 60,
                    width: 242
                },
                items: [{
                    xtype: "TextField",
                    hidden: true,
                    name: "id"
                }, {
                    xtype: "TextField",
                    hidden: true,
                    name: "parentId",
                    value: g.selectedNode.id
                }, {
                    xtype: "TextField",
                    //nameText: 名称
                    title: "名称",
                    name: "name",
                    maxlength: 20,
                    allowBlank: false
                }, {
                    xtype: "TextField",
                    title: "代码",
                    name: "code",
                    maxlength: 20,
                    allowBlank: false
                }, {
                    xtype: "TextField",
                    //rankText: 排序
                    title: "排序",
                    name: "rank",
                    allowBlank: false,
                    allowChar: "1234567890",
                    maxlength: 11,
                    minLengthText: "最大长度为11位",
                    validateText: "排序必须为正整数",
                    validater: function (value) {
                        if(value < 1) {
                            return false;
                        }
                        return true;
                    }
                }]
            }],
            buttons: [{
                //saveText: 保存
                title: "保存",
                selected: true,
                handler: function () {
                    g.save();
                }
            }, {
                //cancleText: 取消
                title: "取消",
                handler: function () {
                    g.editWin.remove();
                }
            }]
        });
        g.createFormCmp = EUI.getCmp("createForm");
    },
    save: function () {
        var g = this, data;
        if (g.isEdit) {
            if (!g.editFormCmp.isValid()) {
                return;
            }
            data = g.editFormCmp.getFormValue();
        } else {
            if (!g.createFormCmp.isValid()) {
                return;
            }
            data = g.createFormCmp.getFormValue();
            delete data.id;
        }
        var myMask = EUI.LoadMask({
            //saveMaskMessageText: 正在保存，请稍候...
            msg: "正在保存，请稍候..."
        });
        EUI.Store({
            url: _ctxPath + "/basic/data/save",
            params: data,
            success: function (result) {
                myMask.hide();
                var status = {
                    msg: result.msg,
                    success: result.success,
                    showTime: result.success ? 2 : 60
                };
                if (status.success) {
                    if (!g.isEdit) {
                        g.editWin.remove();
                    }
                    var nodeData = result.data;
                    var parentData = g.treeCmp.getNodeData(nodeData.parentId);
                    if (g.isEdit) {
                        for (var i = 0; i < parentData.children.length; i++) {
                            if (parentData.children[i].id == nodeData.id) {
                                parentData.children[i].name = nodeData.name;
                                parentData.children[i].code = nodeData.code;
                                parentData.children[i].rank = nodeData.rank;
                            }
                        }
                    } else {
                        if (!parentData.children) {
                            parentData.children = [];
                        }
                        parentData.children.push(nodeData);

                    }
                    parentData.children.sort(function (a, b) {
                        return a.rank - b.rank;
                    });
                    g.treeCmp.initTree();
                    // g.getMenuTreeData();
                    g.treeCmp.setSelect(nodeData.id);
                    g.selectedNode = nodeData;
                    tree = g.treeCmp.data;
                }
                EUI.ProcessStatus(status);
            },
            failure: function (re) {
                myMask.hide();
                var status = {
                    msg: re.msg,
                    success: false,
                    showTime: 6
                };
                EUI.ProcessStatus(status);
            }
        });
    },
    initMain: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "center",
            border: false,
            layout: "border",
            itemspace: 0,
            padding: 1,
            items: [this.initFormBar(), this.initForm()]
        }
    },
    initFormBar: function (){
        var g = this;
        return {
            xtype: "Container",
            region: "north",
            height: 40,
            padding: 1,
            isOverFlow:false,
            border: false,
            html: "<div class='nodePath' style='font-size:20px '>" + "..." + "</div>"
        }
    },
    initForm: function () {
        var g = this;
        return {
            xtype: "FormPanel",
            id: "editForm",
            region: "center",
            padding: 20,
            style:{
                "background":"#fff",
                "min-width" : "435px"
            },
            defaultConfig: {
                labelWidth: 100,
                width: 300
            },
            items: [{
                xtype: "TextField",
                hidden: true,
                name: "id"
            }, {
                xtype: "TextField",
                hidden: true,
                name: "parentId"
            }, {
                xtype: "TextField",
                //codeText: 代码
                title: "代码",
                name: "code",
                maxLength: 10,
                labelWidth : 60,
                readonly: true,
                allowBlank: false
            }, {
                xtype: "TextField",
                //nameText: 名称
                title: "名称",
                name: "name",
                maxLength: 20,
                labelWidth : 60,
                allowBlank: false
            }, {
                xtype: "TextField",
                //rankText: 排序
                title: "排序",
                name: "rank",
                labelWidth : 60,
                allowBlank: false,
                allowChar: "1234567890",
                maxlength: 11,
                minLengthText: "最大长度为11位",
                validateText: "排序必须为正整数",
                validater: function (value) {
                    if(value < 1) {
                        return false;
                    }
                    return true;
                }
            }, {
                xtype: "Button",
                //saveText: 保存
                title: "保存",
                style: {
                    "margin-left": "108px",
                    "margin-top": "20px"
                },
                width: 160,
                align: "center",
                selected: true,
                handler: function () {
                    if (!g.selectedNode) {
                        //addHintMessageText
                        g.message("请选择一个基础数据节点!");
                        return false;
                    } else if (g.selectedNode.parentId == "" || g.selectedNode.parentId == null) {
                        //updateRootText 禁止修改根节点
                        g.message("禁止修改根节点");

                        return false;
                        //g.isEdit = true;
                        //g.saveRootNode();
                    }else{
                        g.isEdit = true;
                        g.save();
                    }

                }
            }]
        }
    },
    openNodeMoveWin: function (nodeData){
        var g = this;
        g.moveNodeId = nodeData.id;
        g.nodeMoveWin = EUI.Window({
            title: "移动节点【" + nodeData.name + "】到",
            height: 360,
            width: 340,
            buttonAlign: 'center',
            items: [{
                xtype: "TreePanel",
                id: "treeWindow",
                data: g.getMoveToData(nodeData),
                onSelect: function (node) {
                    if (node.id == nodeData.id || nodeData.parentId == node.id || node.parentId == nodeData.id ) {
                        g.message("...");
                        EUI.getCmp("treeWindow").clearSelect();
                        return false;
                    }
                    if (nodeData.children.length>0 && node.nodeLevel>0) {
                        g.message("...");
                        EUI.getCmp("treeWindow").clearSelect();
                        return false;
                    }
                    g.targetNode = node;
                }
            }],
            buttons: [{
                //okText: 确定
                title: "确定",
                width: 40,
                selected: true,
                handler: function () {
                    if (g.targetNode.nodeLevel == 2) {
                        g.message("...");
                        EUI.getCmp("treeWindow").clearSelect();
                        return;
                    }
                    g.moveNodeToSave();
                }
            }, {
                //cancelText: 取消
                title: "取消",
                width: 40,
                handler: function () {
                    g.nodeMoveWin.close();
                }
            }]
        });
    },
    getMoveToData: function (moveNode) {
        var g = this;
        // var data = g.treeCmp.data;
        var data = tree;
        return g._getMoveData(data, moveNode);
    },
    _getMoveData: function (nodes, moveNode) {
        if (moveNode == null) {
            return [];
        }
        var result = [];
        for (var i = 0; i < nodes.length; i++) {
            if (moveNode.parentId == nodes[i].id || (nodes[i]["children"] && (nodes[i].id == moveNode.id))) {
                result = result.concat(this._getMoveData(nodes[i]["children"], moveNode));
            } else if (moveNode.id == nodes[i].parentId) {
                continue;
            } else {
                result.push(nodes[i]);
            }
        }
        return result;
    },
    moveNodeToSave: function () {
        var g = this;
        var selNode = g.targetNode;
        if (selNode) {
            var myMask = EUI.LoadMask({
                //queryMaskMessageText: 正在努力获取数据，请稍候...
                msg: "正在努力获取数据，请稍候..."
            });
            EUI.Store({
                url: _ctxPath + "/basic/data/move",
                params: {nodeId: g.moveNodeId, targetParentId: selNode.id},
                success: function (result) {
                    myMask.hide();
                    if (result.success) {
                        g.nodeMoveWin.close();
                        g.getMenuTreeData();
                    }
                    EUI.ProcessStatus(result);
                },
                failure: function (re) {
                    myMask.hide();
                    var status = {
                        msg: re.msg,
                        success: false,
                        showTime: 6
                    };
                    EUI.ProcessStatus(status);
                }
            });
        } else {
            //moveHintMessageText: "请选择您要移动的节点！"
            g.message("请选择您要移动的节点！");
            return false;
        }
    },
    getMenuTreeData: function () {
        var g = this;
        var myMask = EUI.LoadMask({
            msg: "正在努力获取数据，请稍候..."
        });
        EUI.Store({
            url: _ctxPath + "/basic/data/listAllDataTree",
            success: function (result) {
                myMask.hide();
                if (result.success) {
                    g.treeCmp.setData(result.data,true);
                    tree = g.treeCmp.data;
                }
            },
            failure: function (re) {
                myMask.hide();
                EUI.ProcessStatus(re);
            }
        });
    },
    message: function (msg) {
        var g = this;
        var message = EUI.MessageBox({
            border: true,
            //hintText: "提示",
            title: "提示",
            showClose: true,
            msg: msg,
            buttons: [{
                //okText:"确定",
                title: "确定",
                handler: function () {
                    message.remove();
                }
            }]
        });
    }
});