EUI.UserManagementView = EUI.extend(EUI.CustomUI, {
    renderTo: "",
    authority: "",
    currentShowItem: "positionTabItem",//当前活动的tabItem : "positionTabItem","featureroleTabItem","dataroleTabItem",
    checkRefreshTab: {},
    initComponent: function () {
        this.getOrgData();
        EUI.Container({
            renderTo: this.renderTo,
            layout: "border",
            border: false,
            padding: 8,
            itemspace: 0,
            html: "<div id='user' style='display:block;'></div>" +
            "<div id='config'></div>"
        });
        this.initFirstPage();
        this.treeCmp = EUI.getCmp("organization");
        this.userGridCmp = EUI.getCmp("usergrid");
        this.addEvents();
        //this.queryUser();
    },
    getOrgData: function () {
        var g = this;
        var myMask = EUI.LoadMask({
            //loadingMaskMessageText:"正在加载，请稍候..."
            msg: "正在加载，请稍候..."
        });
        EUI.Store({
            url: _ctxPath+"/basic/organization/listAllOrgTreeWithoutFrozen/",
            async: false,
            success: function (status) {
                myMask.remove();
                if (status.success) {
                    g.orgData = status.data;
                } else {
                    EUI.ProcessStatus(status);
                }
            },
            failure: function (status) {
                myMask.hide();
                EUI.ProcessStatus(status);
            }
        });
    },
    /*****-------初始页面-------******/
    initFirstPage: function () {
        EUI.Container({
            layout: "border",
            renderTo: "user",
            border: false,
            padding: 3,
            itemspace: 2,
            isOverFlow: false,
            items: [this.initWest(), this.initCenterUser()]
        });
    },
    /*****-------页面左侧布局-------******/
    initWest: function () {
        var g = this;
        return {
            xtype: "Container",
            layout: "border",
            region: "west",
            border: false,
            width: 450,
            itemspace: 0,
            padding: 0,
            layout: "border",
            items: [this.initWestBar(), this.initWestTree()]
        }
    },
    initWestBar: function () {
        var g = this;
        return {
            xtype: "ToolBar",
            region: "north",
            height: 40,
            padding: 0,
            border: false,
            isOverFlow: false,
            items: ['->', {
                xtype: "SearchBox",
                width: 189,
                displayText: "请输入代码或名称查询",
                onSearch: function (v) {
                    g.treeCmp.search(v);
                    EUI.getCmp("searchBox_usergrid").reset();
                    g.userGridCmp.reset();
                },
                afterClear: function () {
                    g.treeCmp.reset();
                    EUI.getCmp("searchBox_usergrid").reset();
                    g.userGridCmp.reset();
                }
            }]
        };
    },
    initWestTree: function () {
        var g = this;
        return {
            xtype: "TreePanel",
            region: "center",
            border: true,
            id: "organization",
            field: ["organizationId"],
            searchField: ["name"],
            style: {
                "background": "#fff"
            },
            data: g.orgData,
            showField: "name",
            onSelect: function (node) {
                g.selectOrg = node;
//					console.log(JSON.stringify(node))
                $("#namePathTitle").html(node.namePath);
                g.queryUser();
            }
        }
    },

    /*****-------页面右侧布局-------******/
    initCenterUser: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "center",
            layout: "border",
            border: false,
            itemspace: 0,
            padding: 0,
            isOverFlow: false,
            items: [{
                xtype: "Label",
                region: "north",
                border: false,
                height: 40,
                // detailText:"详细信息",
                content: "<div id='namePathTitle' style='font-size:20px;line-height: 40px '>详细信息</div>"
            }, {
                xtype: "Container",
                region: "center",
                layout: "border",
                border: false,
                padding: 0,
                itemspace: -1,
                isOverFlow: false,
                items: [this.initUserGridTbar(), this.initUserGrid()]
            }
            ]
        };
    },
    initUserGridTbar: function () {
        var g = this;
        return {
            xtype: "ToolBar",
            region: "north",
            padding: 0,
            height: 40,
            isOverFlow: false,
            style: {
                // "padding-top": "2px"
            },
            isOverFlow: false,
            items: [{
                xtype: "Button",
                //addText: "新增",
                title: "新增",
                selected: true,
                style: {
                    "margin-right": "0px"
                },
                handler: function () {
                    //addText: "新增"
                    g.opareteUser({}, "新增");
                }
            }, {
                xtype: "Button",
                //configText:"配置",
                title: "配置",
                selected: true,
                handler: function () {
                    var needRefresh = false;
                    var user=EUI.getCmp("user");
                    var config=EUI.getCmp("config");
                    var roleData = g.userGridCmp.getSelectRow();
                    if (!roleData) {
                        //operateHintMessage: "请选择一条要操作的行项目!",
                        g.message("请选择一条要操作的行项目!");
                    } else {
                        var title = "当前用户:【" + roleData.userName + "】";
                        if ($("#currentUserTitle").html() != title) {
                            $("#currentUserTitle").html(title);
                            needRefresh = true;
                        }
                        if(!config){
                            // $("#user").css("display", "none");
                            user.hide();
                            $("#config").css("display", "block");
                        }else{
                            user.hide();
                            config.show();
                        }

                        if ($("#config").children().length == 0) {
                            g.initConfigPage();
                            g.addAssignEvent();
                            needRefresh = false;
                        }
                        if (needRefresh) {
                            g.refreshMainGrid();
                        }
                    }
                }
            },{
                xtype: "Button",
                title: "重置密码",
                handler: function () {
                    var rowData = g.userGridCmp.getSelectRow();
                    if (!rowData) {
                        g.message("请选择一条要操作的行项目!");
                    } else {
                        var infoBox = EUI.MessageBox({
                            title: "提示",
                            msg: "您确定要重置吗？",
                            buttons: [{
                                title: "确定",
                                iconCss:"ecmp-common-ok",
                                handler: function () {
                                    infoBox.remove();
                                    var myMask = EUI.LoadMask({
                                        msg: "正在重置，请稍候..."
                                    });
                                    EUI.Store({
                                        url: _ctxPath+"/basic/userManage/resetPwd",
                                        params: {
                                            employeeId: rowData.id
                                        },
                                        success: function (result) {
                                            myMask.hide();
                                            EUI.ProcessStatus(result);
                                        },
                                        failure: function (re) {
                                            myMask.hide();
                                            EUI.ProcessStatus(re);
                                        }
                                    });
                                }
                            }, {
                                //cancelText:取消
                                title: "取消",
                                iconCss:"ecmp-common-delete",
                                handler: function () {
                                    infoBox.remove();
                                }
                            }]
                        });
                    }
                }
            }, "->", {
                xtype: "SearchBox",
                id: "searchBox_usergrid",
                width: 200,
                //searchDisplayText:"请输入员工编号或名称进行查询"
                displayText: "请输入员工编号或名称进行查询",
                onSearch: function (v) {
                    var queryFormParams = EUI.getCmp("organization").getSubmitValue();
                    EUI.getCmp("usergrid").setPostParams({
                        Quick_value: v,
                        Q_EQ_organizationId: queryFormParams.organizationId
                    }, true);
                },
                afterClear: function () {
                    g.queryUser();
                }
            }]
        };
    },
    initUserGrid: function () {
        var g = this;
        return {
            xtype: "GridPanel",
            id: "usergrid",
            region: "center",
            searchConfig: {
                searchCols: ["code", "userName"]
            },
            gridCfg: {
                datatype: "json",
                url: _ctxPath+'/basic/userManage/listUsers/',
                postData: {"Q_EQ_organizationId":-1},
                colModel: [
                    //operateText:"操作"
                    {
                        name: "operate", index: "operate", width: 40, align: "center", label: "操作",
                        formatter: function (cellvalue, options, rowObject) {
                            var strVar = "<div class='condetail_operate'>"
                                + "<div class='condetail_update'></div></div>";
                            return strVar;
                        }
                    },
                    {name: 'id', hidden: true},
                    {name: 'organizationId', hidden: true},
                    {name: 'frozen', hidden: true},
                    // {name: 'tenantCode', hidden: true},
                    //employeeCodeText:"员工编号",
                    {name: 'code', index: 'code', width: 150, label: "员工编号"},
                    //userNameText:"姓名"
                    {name: 'userName', index: 'userName', width: 100, label: "姓名"}
                ],
                rowNum: 15,
                loadui: "disable",
                shrinkToFit: false,
                sortname: 'code'
            }
        };
    },
    refreshMainGrid: function () {
        var g = this;
        var selectUser = EUI.getCmp("usergrid").getSelectRow();
        var rowid = selectUser ? selectUser.id : "";
        if (!rowid) {
            return;
        }
        if (this.currentShowItem == "positionTabItem") {
            //先获取已分配的岗位，再获取可分配的岗位
            g.refreshAssignedPosition();
            g.refreshUnassignedPosition();
        } else if (this.currentShowItem == "featureroleTabItem") {
            //先获取已分配的功能角色,再获取可分配的功能角色
            g.refreshAssignedFeatureRole();
            g.refreshUnassignedFeatureRole();
        } else if (this.currentShowItem == "dataroleTabItem") {
            //先获取已分配的数据角色，再获取可分配的数据角色
            g.refreshAssignedDataRole();
            g.refreshUnassignedDataRole();
        }
    },
    //查询已分配与未分配的数据
    gridItemQuery: function (gridId, url) {
        var g = this;
        var gridCmp = EUI.getCmp(gridId);
        var myMask = EUI.LoadMask({
            //queryMaskMessageText: "正在努力获取数据，请稍候..."
            msg: "正在努力获取数据，请稍候..."
        });
        EUI.Store({
            async: false,
            url: url,
            success: function (result) {
                myMask.hide();
                gridCmp.setDataInGrid(result, false);
                if (gridId == "unassignedpositiongrid") {
                    var unassignedGridData = EUI.getCmp(gridId).data;
                    var assignedGridData = EUI.getCmp(gridId.substring(2)).data;
                    if (unassignedGridData && assignedGridData) {
                        for (var i = 0; i < assignedGridData.length; i++) {
                            for (var j = 0; j < unassignedGridData.length; j++) {
                                if (unassignedGridData[j].id == assignedGridData[i].id) {
                                    gridCmp.deleteRow(unassignedGridData[j].id);
                                }
                            }
                        }
                    }
                }
            },
            failure: function (re) {
                myMask.hide();
                var status = {
                    msg: re.msg?re.msg:"调用出错了",
                    success: false,
                    showTime: 6
                };
                EUI.ProcessStatus(status);
            }
        });
    },
    //分配或移除操作
    distributeOrRemoveOperate: function (gridId, rowId) {
        var g = this, gridCmp = EUI.getCmp(gridId), ids = [], data, url;
        var userId = EUI.getCmp("usergrid").getSelectRow().id;
        if (rowId && rowId != "") {
            ids.push(rowId);
        } else {
            var rows = gridCmp.getSelectRow();
            if (rows.length > 0) {
                for (var i = 0; i < rows.length; i++) {
                    ids.push(rows[i].id);
                }
            } else {
                //operateHintMessage: "请选择一条要操作的行项目!",
                g.message("请选择一条要操作的行项目!");
                return false;
            }
        }

        switch (gridId) {
            case "unassignedpositiongrid":
                data = {userId: userId, positionIds: ids};
                url = _ctxPath+"/basic/userManage/insertPositions/";
                break;
            case "unassignedfeaturerolegrid":
                data = {userId: userId, featureRoleIds: ids};
                url = _ctxPath+"/basic/userManage/insertFeatureRoles/";
                break;
            case "unassigneddatarolegrid":
                data = {userId: userId, dataRoleIds: ids};
                url = _ctxPath+"/basic/userManage/insertDataRoles/";
                break;
            case "assignedpositiongrid":
                data = {userId: userId, positionIds: ids};
                url = _ctxPath+"/basic/userManage/removePositions/";
                break;
            case "assignedfeaturerolegrid":
                data = {userId: userId, featureRoleIds: ids};
                url = _ctxPath+"/basic/userManage/removeFeatureRoles/";
                break;
            case "assigneddatarolegrid":
                data = {userId: userId, dataRoleIds: ids};
                url = _ctxPath+"/basic/userManage/removeDataRoles/";
                break;
            default:
                return;
        }
        g.dataOperate(gridId, url, data);
    },
    //完成分配，移除的后台请求
    dataOperate: function (gridId, url, params) {
        var g = this, rowId;
        var gridCmp = EUI.getCmp(gridId);
        var myMask = EUI.LoadMask({
            //removingText: "正在移除，请稍候...",
            //distributingText: "正在分配，请稍候...",
            msg: gridId.indexOf("un") == 0 ? "正在分配，请稍候..." : "正在移除，请稍候..."
        });
        EUI.Store({
            url: url,
            params: params,
            success: function (result) {
                myMask.hide();
                var status = {
                    msg: result.msg,
                    success: result.success,
                    showTime: result.success ? 2 : 60
                };
                if (status.success) {
                    switch (gridId) {
                        case "assignedpositiongrid":                     //调用移除方法
                            g.refreshAssignedPosition();       //刷新已分配的岗位
                            g.refreshUnassignedPosition();                  //刷新未分配的岗位
                            g.filterDataBySearchConditions("unassignedpositiongrid");
                            break;
                        case "unassignedpositiongrid":                   //调用分配方法
                            g.refreshAssignedPosition();       //刷新已分配的岗位
                            g.refreshUnassignedPosition();                  //刷新未分配的岗位
                            g.filterDataBySearchConditions("assignedpositiongrid");
                            break;
                        case "assignedfeaturerolegrid":                  //调用移除方法
                            g.refreshAssignedFeatureRole();     //刷新已分配功能角色
                            g.refreshUnassignedFeatureRole();                   //刷新未分配的功能角色
                            g.filterDataBySearchConditions("unassignedfeaturerolegrid");
                            break;
                        case "unassignedfeaturerolegrid":                //调用分配方法
                            g.refreshAssignedFeatureRole();     //刷新已分配功能角色
                            g.refreshUnassignedFeatureRole();                   //刷新未分配的功能角色
                            g.filterDataBySearchConditions("assignedfeaturerolegrid");
                            break;
                        case "assigneddatarolegrid":
                            g.refreshAssignedDataRole();     //刷新已分配数据角色
                            g.refreshUnassignedDataRole();                //刷新未分配的数据角色
                            g.filterDataBySearchConditions("unassigneddatarolegrid");
                            break;
                        case "unassigneddatarolegrid":
                            g.refreshAssignedDataRole();     //刷新已分配数据角色
                            g.refreshUnassignedDataRole();                //刷新未分配的数据角色
                            g.filterDataBySearchConditions("assigneddatarolegrid");
                            break;
                    }
                }
                EUI.ProcessStatus(status);
            },
            failure: function (re) {
                myMask.hide();
                var status = {
                    msg: re.msg,
                    success: false,
                    showTime: 6
                };
                EUI.ProcessStatus(status);
            }
        });
    },
    //完成分配，移除的后台请求后根据查询条件进行过滤
    filterDataBySearchConditions: function (gridId) {
        EUI.getCmp("searchBox_" + gridId).reset();
    },
    //刷新未分配的岗位
    refreshUnassignedPosition: function () {
        var data = EUI.getCmp("organizationforsearch").getSubmitValue();
        var orgId = data ? data.organizationId : null;
        if (orgId) {
            this.gridItemQuery("unassignedpositiongrid", _ctxPath+"/basic/userManage/listAllCanAssignPositionsByOrganization/?organizationId=" + orgId);
        } else {
            this.gridItemQuery("unassignedpositiongrid", _ctxPath+"/basic/userManage/listAllCanAssignPositionsByUser?userId=" + EUI.getCmp("usergrid").getSelectRow().id);
        }
    },
    //刷新未分配的功能角色
    refreshUnassignedFeatureRole: function () {
        var data = EUI.getCmp("featurerolegroupforsearch").getSubmitValue();
        var featureRoleGroupId = data ? data.featureRoleGroupId : null;
        var rowId = this.userGridCmp.getSelectRow().id;
        if (featureRoleGroupId) {
            this.gridItemQuery("unassignedfeaturerolegrid", _ctxPath+"/basic/userManage/listAllCanAssignFeatureRolesByRoleGroupAndUser?featureRoleGroupId=" + featureRoleGroupId + "&userId=" + rowId);
        } else {
            this.gridItemQuery("unassignedfeaturerolegrid", _ctxPath+"/basic/userManage/listAllCanAssignFeatureRolesByUser?userId=" + rowId);
        }
    },
    //刷新未分配的数据角色
    refreshUnassignedDataRole: function () {
        var data = EUI.getCmp("datarolegroupforsearch").getSubmitValue();
        var dataRoleGroupId = data ? data.dataRoleGroupId : null;
        var rowId = this.userGridCmp.getSelectRow().id;
        if (dataRoleGroupId) {
            this.gridItemQuery("unassigneddatarolegrid", _ctxPath+"/basic/userManage/listAllCanAssignDataRolesByRoleGroupAndUser?dataRoleGroupId=" + dataRoleGroupId + "&userId=" + rowId);
        } else {
            this.gridItemQuery("unassigneddatarolegrid", _ctxPath+"/basic/userManage/listAllCanAssignDataRolesByUser?userId=" + rowId);
        }
    },
    //刷新已分配的岗位
    refreshAssignedPosition: function () {
        this.gridItemQuery("assignedpositiongrid", _ctxPath+"/basic/userManage/listAllAssignedPositionsByUser?userId=" + EUI.getCmp("usergrid").getSelectRow().id);
    },
    //刷新已分配的功能角色
    refreshAssignedFeatureRole: function () {
        this.gridItemQuery("assignedfeaturerolegrid", _ctxPath+"/basic/userManage/listAllAssignedFeatureRoles?userId=" + EUI.getCmp("usergrid").getSelectRow().id);
    },
    //刷新已分配的数据角色
    refreshAssignedDataRole: function () {
        this.gridItemQuery("assigneddatarolegrid", _ctxPath+"/basic/userManage/listAllAssignedDataRoles?userId=" + EUI.getCmp("usergrid").getSelectRow().id);
    },
    /*****-------跳转配置布局-------******/
    initConfigPage: function () {
        var g = this;
        EUI.Container({
            renderTo: "config",
            layout: "border",
            itemspace: 1,
            items: [g.initReturnBar(), g.initMain()]
        });
    },
    initReturnBar: function () {
        var g = this;
        return {
            xtype: "ToolBar",
            region: "north",
            border: false,
            height: 40,
            padding: 0,
            isOverFlow: false,
            items: [{
                xtype: "Button",
                //revertText:"返回"
                title: "返回",
                selected: true,
                handler: function () {
                    /*$("#config").css("display", "none");
                    $("#user").css("display", "block");*/
                    EUI.getCmp("config").hide();
                    EUI.getCmp("user").show();
                }
            }, {
                xtype: "Container",
                border: false,
                width: 400,
                height: 40,
                padding: 0,
                html: "<div id='currentUserTitle' style='font-size:15px;padding-top: 4px'>当前用户:【" + g.userGridCmp.getSelectRow().userName + "】</div>"
            }]
        }
    },
    /*****-------页面右侧布局-------******/
    initMain: function () {
        var g = this;
        return {
            xtype: "TabPanel",
            region: "center",
            itemspace: 0,
            border: true,
            autoScroll: false,
            showTabMenu: false,
            isOverFlow: false,
            defaultConfig: {
                padding: 1
            },
            //assignPositionText:"配置岗位",
            //assignFeatureRoleText:"配置功能角色",
            //assignDataRoleText:"配置数据角色",
            items: [
//					this.getTabItem("position", "配置岗位"),
                this.getTabItem("featurerole", "配置功能角色"),
                this.getTabItem("datarole", "配置数据角色")
            ],
            onActive: function (id) {
                g.currentShowItem = id;
                var selectRowPosition = EUI.getCmp("usergrid").getSelectRow();
                if (!selectRowPosition) {
                    return;
                }
                if (g.checkRefreshTab[id] != selectRowPosition.id) {
                    g.checkRefreshTab[id] = selectRowPosition.id;
                    g.refreshMainGrid();
                }
            }
        };
    },
    getTabItem: function (itemType, title) {
        return {
            id: itemType + "TabItem",
            title: title,
            closable: false,// 右上角关闭按钮是否显示
            iframe: false,
            layout: "border",
            items: [this.initMainWest(itemType), this.initMainCenter(itemType)]
        }
    },
    /********----Main布局----********/
    initMainWest: function (itemType) {
        return {
            xtype: "Container",
            region: "west",
            layout: "border",
            border: false,
            padding: 0,
            width: 500,
            itemspace: -1,
            isOverFlow: false,
            items: [{
                xtype: "Container",
                region: "west",
                layout: "border",
                border: false,
                padding: 0,
                width: 450,
                itemspace: -1,
                isOverFlow: false,
                items: [
                    //assignedText:"已分配",
                    this.initTitle("已分配"), {
                        xtype: "Container",
                        region: "center",
                        layout: "border",
                        border: false,
                        padding: 0,
                        itemspace: -1,
                        isOverFlow: false,
                        items: [this.initMainGridTbar("assigned", itemType), this.initMainGrid("assigned", itemType)]
                    }]
            }, this.getCenterIcon()]
        };
    },
    initMainCenter: function (itemType) {
        return {
            xtype: "Container",
            region: "center",
            layout: "border",
            border: false,
            padding: 1,
            itemspace: -1,
            isOverFlow: false,
            //unassignedText:"可分配",
            items: [this.initTitle("可分配"), {
                xtype: "Container",
                region: "center",
                layout: "border",
                height: 100,
                border: false,
                padding: 0,
                itemspace: -1,
                isOverFlow: false,
                items: [this.initMainGridTbar("unassigned", itemType), this.initMainGrid("unassigned", itemType)]
            }]
        };
    },
    getCenterIcon: function () {
        var g = this;
        return {
            xtype: "Container",
            region: "center",
            width: 50,
            border: false,
            isOverFlow: false,
            html: "<div class='arrow-right'></div>" +
            "<div class='arrow-left'></div>"
        }
    },
    initTitle: function (title) {
        return {
            xtype: "Container",
            region: "north",
            border: true,
            height: 34,
            isOverFlow: false,
            html: "<div style='font-size:15px;overflow:hidden;'>" + title + "</div>"
        }
    },
    initMainGridTbar: function (assignType, itemType) {
        var g = this, gridId = assignType + itemType + "grid";
        var isUnAssign = assignType == "unassigned";
        var items = [];
        if (isUnAssign) {
            if (itemType == "position") {
                items.push({
                    xtype: "ComboTree",
                    //organizationNameText: "组织机构",
                    width: 130,
                    labelWidth: 90,
                    id: "organizationforsearch",
                    title: "组织机构",
                    name: "organizationName",
                    field: ["organizationId"],
                    canClear: true,
                    style: {
                        "margin-left": "9px"
                    },
                    data: g.orgData,
                    treeCfg: {
                        showField: "name"
                    },
                    afterClear: function () {
                        var rowid = EUI.getCmp("usergrid").getSelectRow().id;
                        g.gridItemQuery("unassignedpositiongrid", _ctxPath+"/basic/userManage/listAllCanAssignPositionsByUser?userId=" + rowid);
                    },
                    afterSelect: function (value) {
                        g.gridItemQuery("unassignedpositiongrid", _ctxPath+"/basic/userManage/listAllCanAssignPositionsByOrganization/?organizationId=" + value.data.id);
                    },
                    reader: {
                        field: ["id"],
                        name: "name"
                    }
                });
            }
            if (itemType == "featurerole") {
                items.push({
                    id: "featurerolegroupforsearch",
                    xtype: "ComboGrid",
                    //featureRoleGroupNameText: "功能角色组",
                    title: "功能角色组",
                    //  name: "featureRoleName",
                    width: 130,
                    labelWidth: 90,
                    field: ["featureRoleGroupId"],
                    showSearch: true,
                    searchConfig: {searchCols: ["code", "name"]},
                    listWidth: 400,
                    padding: 5,
                    canClear: true,
                    gridCfg: {
                        url: _ctxPath+"/basic/featureRole/listAllFeatureRoleGroup/",
                        shrinkToFit: false,
                        loadonce: true,
                        colModel: [
                            {name: 'id', hidden: true},
                            //codeText: "代码"
                            {name: 'code', index: 'Code', width: 70, label: "代码"},
                            //nameText: "名称"
                            {name: 'name', index: 'Name', label: "名称", width: 220}
                        ]
                    },
                    afterClear: function () {
                        var rowid = g.userGridCmp.getSelectRow().id;
                        g.gridItemQuery("unassignedfeaturerolegrid", _ctxPath+"/basic/userManage/listAllCanAssignFeatureRolesByUser?userId=" + rowid);
                    },
                    afterSelect: function (value) {
                        var rowid = g.userGridCmp.getSelectRow().id;
                        g.gridItemQuery("unassignedfeaturerolegrid", _ctxPath+"/basic/userManage/listAllCanAssignFeatureRolesByRoleGroupAndUser?featureRoleGroupId=" + value.data.id + "&userId=" + rowid);
                    },
                    onSearch: function (data) {
                        if (data) {
                            EUI.getCmp("featurerolegroupforsearch").grid.localSearch(data);
                        } else {
                            EUI.getCmp("featurerolegroupforsearch").grid.restore();
                        }
                    },
                    reader: {
                        field: ["id"],
                        name: "name"
                    }
                });
            }
            if (itemType == "datarole") {
                items.push({
                    width: 130,
                    labelWidth: 90,
                    listWidth: 400,
                    padding: 5,
                    id: "datarolegroupforsearch",
                    xtype: "ComboGrid",
                    //dataRoleGroupNameText: "数据角色组",
                    title: "数据角色组",
                    name: "dataRoleGroupName",
                    field: ["dataRoleGroupId"],
                    canClear: true,
                    showSearch: true,
                    searchConfig: {searchCols: ["code", "name"]},
                    gridCfg: {
                        url: _ctxPath+"/basic/dataRole/listAllDataRoleGroup/",
                        shrinkToFit: false,
                        loadonce: true,
                        colModel: [
                            {name: 'id', hidden: true},
                            //codeText: "代码"
                            {name: 'code', index: 'Code', width: 100, label: "代码"},
                            //nameText: "名称"
                            {name: 'name', index: 'Name', label:"名称", width: 220}
                        ]
                    },
                    afterClear: function () {
                        var rowid = g.userGridCmp.getSelectRow().id;
                        g.gridItemQuery("unassigneddatarolegrid", _ctxPath+"/basic/userManage/listAllCanAssignDataRolesByUser/?userId=" + rowid);
                    },
                    afterSelect: function (data) {
                        var rowid = g.userGridCmp.getSelectRow().id;
                        g.gridItemQuery("unassigneddatarolegrid", _ctxPath+"/basic/userManage/listAllCanAssignDataRolesByRoleGroupAndUser/?dataRoleGroupId=" + data.data.id + "&userId=" + rowid);
                    },
                    onSearch: function (data) {
                        if (data) {
                            EUI.getCmp("datarolegroupforsearch").grid.localSearch(data);
                        } else {
                            EUI.getCmp("datarolegroupforsearch").grid.restore();
                        }
                    },
                    reader: {
                        name: "name",
                        field: ["id"]
                    }
                });
            }
        }
        items.push("->", {
            xtype: "SearchBox",
            id: "searchBox_" + gridId,   //"searchBox_assignedpositiongrid"
            width: 150,
            //searchDisplayText:"请输入代码或名称进行查询"
            displayText: "请输入代码或名称进行查询",
            onSearch: function (v) {
                EUI.getCmp(gridId).localSearch(v);
            },
            afterClear: function () {
                EUI.getCmp(gridId).restore();
            }
        });
        return {
            xtype: "ToolBar",
            region: "north",
            padding: 0,
            height: 38,
            isOverFlow: false,
            style: {
                "padding-top": "2px"
            },
            items: items
        };
    },
    initMainGrid: function (assignType, itemType) {
        var searchConfig = {
            searchCols: ["code", "name"]
        };
        return {
            xtype: "GridPanel",
            id: assignType + itemType + "grid",//assignedpositiongrid
            region: "center",
            searchConfig: searchConfig,
            isOverFlow: false,
            gridCfg: this.getMainGridCfg(itemType)
        };
    },
    getMainGridCfg: function (itemType) {
        var colModel, g = this;
        switch (itemType) {
            case "position":
                colModel = [
                    {name: 'id', hidden: true},
                    //codeText: "代码",
                    {name: 'code', index: 'code', width: 60, label: "代码"},
                    //nameText: "名称",
                    {name: 'name', index: 'name', width: 120, label: "名称"},
                    // categoryNameText:"岗位类别",
                    //{name: 'categoryName',index: 'categoryName', width: 100, label:"岗位类别"},
                    //organizationNameText: "组织机构"
                    {
                        name: 'organizatioNamePath',
                        index: 'organizatioNamePath',
                        width: 150,
                        label: "组织机构"
                    }
                ];
                break;
            case "featurerole":
            case "datarole":
                colModel = [
                    {name: 'id', hidden: true},
                    //roleCodeText: "角色代码",
                    {name: 'code', index: 'code', width: 130, label: "角色代码"},
                    //roleNameText: "角色名称",
                    {name: 'name', index: 'name', width: 230, label: "角色名称"}
                ];
                break;
            default:
                return;
        }
        return {
            datatype: "local",
            loadonce: true,
            colModel: colModel,
            rowNum: 15,
            //localReader:"Id",
            shrinkToFit: false,
            sortname: 'code',
            multiselect: true,
            ondblClickRow: function (rowid) {
                var gridId = this.id.split("_")[1];
                g.distributeOrRemoveOperate(gridId, rowid);
            }
        };
    },
    /********----员工操作----*********/
    queryUser: function () {
        var postdata = {}, g = this;
        var queryFormParams = g.selectOrg?g.selectOrg:{id:-1};
        postdata["Q_EQ_organizationId"] = queryFormParams.id;
        postdata["Quick_value"] = EUI.getCmp("searchBox_usergrid").getValue();
        var myMask = EUI.LoadMask({
            //queryMaskMessageText: "正在努力获取数据，请稍候..."
            msg: "正在努力获取数据，请稍候..."
//				target : g.gridCmp.dom
        });
        var userGridCmp = EUI.getCmp("usergrid");
        userGridCmp.grid.jqGrid("setGridParam", {
            postData: postdata,
            loadComplete: function () {
                myMask.hide();
            }
        });
        userGridCmp.refreshGrid();
    },
    addEvents: function () {
        var g = this;
        $(".condetail_update").live("click", function () {
            //modifyText:"修改"
            g.opareteUser(EUI.getCmp("usergrid").getSelectRow(), "修改");
        });
        $(".condetail_delete").live("click", function () {
            g.deleteData(EUI.getCmp("usergrid").getSelectRow());
        });
    },
    addAssignEvent: function () {
        var g = this;
        $(".arrow-right").live("click", function (e) {
            var gridId, name;
            //positionText: "岗位",
            //featureRoleText: "功能角色",
            //dataRoleText: "数据角色",
            switch (g.currentShowItem) {
                case "positionTabItem":
                    gridId = "assignedpositiongrid";
                    name = "岗位";
                    break;
                case "featureroleTabItem":
                    gridId = "assignedfeaturerolegrid";
                    name = "功能角色";
                    break;
                case "dataroleTabItem":
                    gridId = "assigneddatarolegrid";
                    name = "数据角色";
                    break;
            }
            if (!gridId) {
                return false;
            }
            if (g.userGridCmp.getSelectRow().id == __SessionUser["userId"]) {
                //unAssignOperateText:"禁止移除当前用户的【{0}】",
                g.message(String.format("禁止移除当前用户的【{0}】", name));
                return false;
            }
            g.distributeOrRemoveOperate(gridId);
        });
        $(".arrow-left").live("click", function (e) {
            var gridId, name;
            switch (g.currentShowItem) {
                case "positionTabItem":
                    gridId = "unassignedpositiongrid";
                    name = "岗位";
                    break;
                case "featureroleTabItem":
                    gridId = "unassignedfeaturerolegrid";
                    name = "功能角色";
                    break;
                case "dataroleTabItem":
                    gridId = "unassigneddatarolegrid";
                    name = "数据角色";
                    break;
            }
            if (!gridId) {
                return false;
            }
            if (g.userGridCmp.getSelectRow().id == __SessionUser["userId"]) {
                //assignOperateText:"禁止为当前用户分配【{0}】",
                g.message(String.format("禁止为当前用户分配【{0}】", name));
                return false;
            }
            g.distributeOrRemoveOperate(gridId);
        });
    },
    deleteData: function (data) {
        var g = this;
        if (data && data.id) {
            var message = EUI.MessageBox({
                border: true,
                //hintText: "提示",
                title: "提示",
                showClose: true,
                //deleteHintMessageText:"您确定要删除吗？"
                msg: "您确定要删除吗？",
                buttons: [{
                    //okText:"确定"
                    title: "确定",
                    selected: true,
                    handler: function () {
                        var myMask = EUI.LoadMask({
                            //deleteMaskMessageText:"正在删除，请稍候..."
                            msg: "正在删除，请稍候..."
                        });
                        EUI.Store({
                            url: _ctxPath+"/basic/userManage/delete/",
                            params: {id: data.id},
                            success: function (status) {
                                myMask.remove();
                                EUI.ProcessStatus(status);
                                if (status.success) {
                                    // g.gridCmp.grid.trigger("reloadGrid");
                                    EUI.getCmp("usergrid").refreshGrid();
                                }
                            },
                            failure: function (status) {
                                myMask.hide();
                                EUI.ProcessStatus(status);
                            }
                        });
                        message.remove();
                    }
                }, {
                    //cancelText:"取消",
                    title: "取消",
                    handler: function () {
                        message.remove();
                    }
                }]
            });
        } else {
            // operateHintMessage:"请选择一条要操作的行项目!",
            g.message("请选择一条要操作的行项目!");
        }
    },
    opareteUser: function (data, title) {
        var g = this;
        if (!g.selectOrg || !g.selectOrg.name) {
            //validOrganizationText:"请先选择组织机构！"
            g.message("请先选择组织机构！");
            return;
        }
        var orgData = {
            organizationName: g.selectOrg.name,
            organizationId: g.selectOrg.id
        };
        EUI.apply(data, orgData);
        g.win = EUI.Window({
            title: title,
            width: 360,
            height: 160,
            padding: 10,
            items: [g.getForm()],
            buttons: [{
                //saveText:"保存"
                title: "保存",
                selected: true,
                handler: function () {
                    g.saveData();
                }
            }, {
                //cancelText:"取消"
                title: "取消",
                handler: function () {
                    g.win.remove();
                }
            }]
        });
        EUI.getCmp("empolyeeform").loadData(data);
    },
    getForm: function () {
        var g = this;
        return {
            xtype: "FormPanel",
            id: "empolyeeform",
            // region: "north",
            // layout: "auto",
            itemspace: 10,
            border: false,
            isOverFlow: false,
            style: {
                "padding-left": "0px"
            },
            /* defaultStyle: {
                 allowBlank: false,
                 labelWidth: 90,
                 width: 240,
                 xtype: "TextField"
             },*/
            items: [{
                xtype: "TextField",
                allowBlank: false,
                labelWidth: 90,
                width: 240,
                hidden: true,
                name: "id"
            }, {
                xtype: "TextField",
                allowBlank: false,
                labelWidth: 90,
                width: 240,
                id: "empolyeeorg",
                field: ["organizationId"],
                title: "组织机构",
                readonly: true,
                name: "organizationName"
            }, {
                title: "帐号",
                name: "code",
                xtype: "TextField",
                allowBlank: false,
                labelWidth: 90,
                width: 240,
                afterValid: function (valid) {
//						EUI.TextField().afterValid.call(this, valid);
//						this.dom.field.val(this.getValue().toUpperCase());
                }
            }, {
                //userNameText: "姓名",
                title: "名称",
                xtype: "TextField",
                allowBlank: false,
                labelWidth: 90,
                width: 240,
                name: "userName"
            }, {
                xtype: "CheckBox",
                //frozenText:'是否冻结'
                title: "是否冻结",
                labelWidth: 90,
                width: 240,
                name: "frozen"
            }/*,{
             id: "userAuthorityPolicy",
             xtype: "ComboBox",
             store: {
             url: _ctxPath+"/basic/userManage/listAllUserAuthorityPolicy"
             },
             title: "权限策略",
             name: "userAuthorityPolicyRemark",
             reader: {name: 'remark', field: ['name']},
             field: ["userAuthorityPolicy"],
             editable: true
             //					allowBlank: true
             }*/
            ]
        }
    },
    saveData: function () {
        var g = this;
        if (!EUI.getCmp("empolyeeform").isValid()) {
            //saveValidText:"有必输项未填入,请修改后再保存!",
            g.message("有必输项未填入,请修改后再保存!");
            return;
        }
        var data = EUI.getCmp("empolyeeform").getFormValue();
        if (data.id == "") {
            delete data.id;
        }
        var myMask = EUI.LoadMask({
            //saveMaskMessageText:"正在保存，请稍候...",
            msg: "正在保存，请稍候..."
        });
        EUI.Store({
            url: _ctxPath+"/basic/userManage/save",
            params: data,
            success: function (status) {
                console.log(JSON.stringify(status));
                myMask.hide();
                // showTime : 2
                EUI.ProcessStatus(status);
                if (status.success) {
                    g.win.close();
                    //g.queryUser();
                    EUI.getCmp("usergrid").refreshGrid();
                }
            },
            failure: function (re) {
                console.log(JSON.stringify(re));
                myMask.hide();
                EUI.ProcessStatus(re);
            }
        });
    },
    message: function (msg) {
        var g = this;
        var message = EUI.MessageBox({
            border: true,
            //hintText: "提示",
            title: "提示",
            showClose: true,
            msg: msg,
            buttons: [{
                //okText:"确定",
                title: "确定",
                handler: function () {
                    message.remove();
                }
            }]
        });
    }
});