﻿EUI.MiniprogOrderManageView = EUI.extend(EUI.CustomUI, {
    orderStatus: "",
    curPage: null,
    startDay: new Date().format("yyyyMMdd").substr(4, 2) == "01"
        ? new Date().format("yyyyMMdd") - 8900
        : new Date().format("yyyyMMdd") - 100,
    endDay: new Date().format("yyyy-MM-dd"),
    newStartDay: null,
    serviceTypeData:null,
    initComponent: function () {
        this.handleDate();
        EUI.Container({
            renderTo: this.renderTo,
            layout: "border",
            border: false,
            padding: 8,
            itemspace: 0,
            items: [this.initTbar(), this.initGrid()]
        });
        this.getServiceTypeData();
        this.addEvents();
    },
    initTbar: function () {
        var g = this;
        var yearEnd = new Date().format("yyyy-MM-dd");
        var startdate = g.startDay.toString().substr(0, 4) + "-"
            + g.startDay.toString().substr(4, 2) + "-"
            + g.startDay.toString().substr(6, 2);
        return {
            xtype: "ToolBar",
            region: "north",
            height: 50,
            padding: 10,
            style: {
                overflow: "hidden"
            },
            border: false,
            items: [{
                xtype: "DateField",
                name: "startDay",
                id: "startDay",
                value: startdate,
                allowBlank: false,
                style: {
                    "margin-right": "2px"
                },
                maxDate: new Date().format("yyyyMMdd"),
                msg: "起始日期不能大于结束日期",
                width: 120,
                afterSelect: function (data) {
                    g.startDay = data.replace(/-/g, "");
                    g.handleDate();
                    EUI.getCmp("endDay").minDate = g.startDay;
                }
            }, {
                xtype: "DateField",
                name: "endDay",
                title: "至",
                labelWidth: 28,
                colon: false,
                style: {
                    "margin-left": "2px"
                },
                minDate: g.startDay,
                maxDate: new Date().format("yyyyMMdd"),
                msg: "结束日期不能小于起始或超过当前日期",
                id: "endDay",
                afterSelect: function (data) {
                    g.endDay = data;
                    EUI.getCmp("startDay").maxDate = g.endDay;
                },
                value: new Date().format("yyyy-MM-dd"),
                width: 120
            }, {
                xtype: "ComboBox",
                title: "订单状态",
                width: 100,
                labelWidth: 70,
                // id: "curOrderStatus",
                name: "curOrderStatus",
                field: ["code"],
                value: "全部状态",
                data: [{
                    name: "全部状态",
                    code: ""
                }, {
                    name: "已下单",
                    // code: "PLACEORDER"
                    code: "0"
                }, {
                    name: "已预约",
                    // code: "RESERVATION"
                    code: "1"
                }, {
                    name: "已完工",
                    // code: "COMPLETED"
                    code: "2"
                }],
                reader: {
                    name: "name",
                    field: ["code"]
                },
                afterSelect: function (data) {
                    EUI.getCmp("gridPanel").setGridParams({
                        page: 1
                    });
                    EUI.getCmp("gridPanel").setPostParams({
                        Q_EQ_curOrderStatus__int: data.data.code
                    }, true);
                }
            }, {
                xtype: "Button",
                title: "查询",
                selected: true,
                handler: function () {
                    g.initParams();
                }
            }, "->",{
                xtype: "Button",
                title: "录单",
                selected: true,
                handler: function () {
                    g.addOrderWind();
                }
            }, {
                xtype: "SearchBox",
                width: 400,
                displayText: "请输入单号、用户姓名、电话、地址进行模糊搜索",
                onSearch: function (value) {
                    EUI.getCmp("gridPanel").setPostParams({
                        QV_orderNum__userName__userPhone__address: value
                    }, true);
                }
            }]
        };
    },
    initGrid: function () {
        var g = this;
        return {
            xtype: "GridPanel",
            region: "center",
            id: "gridPanel",
            style: {
                "border-radius": "3px"
            },
            gridCfg: {
                // loadonce: true,
                shrinkToFit: false,//固定宽度
                url: _ctxPath + "/mobile/order/listAllOrder",
                postData: {
                    S_createTime: "DESC",
                    Q_GE_createTime__Date: g.newStartDay,
                    Q_LE_createTime__Date: g.endDay
                },
                colModel: [{
                    label: "ID",
                    name: "id",
                    index: "id",
                    hidden: true
                }, {
                    label: "单号",
                    name: "orderNum",
                    index: "orderNum",
                    width: 125
                }, {
                    label: "下单时间",
                    name: "createTime",
                    index: "createTime",
                    width: 140
                }, {
                    label: "openId",
                    name: "openId",
                    index: "openId",
                    hidden: true
                }, {
                    label: "用户姓名",
                    name: "userName",
                    index: "userName",
                    width: 70
                }, {
                    label: "用户电话",
                    name: "userPhone",
                    index: "userPhone",
                    width: 90
                }, {
                    label: "地址",
                    name: "address",
                    index: "address",
                    width: 230
                }, {
                    label: "品类code",
                    name: "code",
                    index: "code",
                    width: 230,
                    hidden: true
                }, {
                    label: "品类",
                    name: "content",
                    index: "content",
                    width: 50
                }, {
                    label: "服务类型code",
                    name: "serviceTypeCode",
                    index: "serviceTypeCode",
                    width: 230,
                    hidden: true
                }, {
                    label: "服务类型",
                    name: "serviceTypeName",
                    index: "serviceTypeName",
                    width: 70
                }, {
                    label: "问题描述",
                    name: "remark",
                    index: "remark",
                    width: 180
                }, {
                    label: "当前订单状态",
                    name: "curOrderStatus",
                    index: "curOrderStatus",
                    align: "center",
                    width: 100,
                    formatter: function (cellvalue, options, rowObject) {
                        var strVar = '';
                        if ('PLACEORDER' == rowObject.curOrderStatus) {
                            strVar = "已下单";
                        }
                        else if ('RESERVATION' == rowObject.curOrderStatus) {
                            strVar = "已预约";
                        } else if ('COMPLETED' == rowObject.curOrderStatus) {
                            strVar = "已完工";
                        }
                        return strVar;
                    }
                }, {
                    label: "所负责工程师id",
                    name: "engineerRepair.id",
                    index: "engineerRepair.id",
                    hidden: true
                }, {
                    label: "所负责工程师",
                    name: "engineerRepair.engineerName",
                    index: "engineerRepair.engineerName",
                    width: 100
                }, {
                    label: "备注",
                    name: "beiZhu",
                    index: "beiZhu",
                    hidden: true
                }, {
                    label: "所属分公司",
                    name: "orgId",
                    index: "orgId",
                    hidden: true
                }, {
                    label: "操作",
                    name: "operate",
                    index: "operate",
                    width: 80,
                    align: "center",
                    formatter: function (cellvalue, options, rowObject) {
                        if (rowObject.curOrderStatus == "PLACEORDER") {
                            return "<div class='cell_operate dealOrder'>处理</div>";
                        }
                        if (rowObject.curOrderStatus == "RESERVATION") {
                            return "<div class='cell_operate dealOrderSecond'>处理</div>";
                        }
                        if (rowObject.curOrderStatus == "COMPLETED") {
                            return "<div class='cell_operate lookOrder'>查看</div>";
                        }

                    }
                }]
            }
        };
    },
    addEvents: function () {
        var g = this;
        $(".dealOrder").live("click", function () {
            var rowData = EUI.getCmp("gridPanel").getSelectRow();
            var page = EUI.getCmp("gridPanel").grid.jqGrid('getGridParam', 'page');
            g.curPage = page;
            g.dealOrderWind(rowData);
            console.log(rowData)
        });
        $(".dealOrderSecond").live("click", function () {
            var rowData = EUI.getCmp("gridPanel").getSelectRow();
            var page = EUI.getCmp("gridPanel").grid.jqGrid('getGridParam', 'page');
            g.curPage = page;
            g.dealOrderSecondWind(rowData);
            console.log(rowData)
        });
        $(".lookOrder").live("click", function () {
            var rowData = EUI.getCmp("gridPanel").getSelectRow();
            var page = EUI.getCmp("gridPanel").grid.jqGrid('getGridParam', 'page');
            g.curPage = page;
            g.lookOrderWind(rowData);
        });
    },
    dealOrderWind: function (data) {
        var g = this;
        var canChooseStatus = [];
        var item1 = {};
        var item2 = {};
        var item3 = {};
        item1.name = "已下单";
        item1.code = "PLACEORDER";
        item2.name = "已预约";
        item2.code = "RESERVATION";
        item3.name = "已完工";
        item3.code = "COMPLETED";
        canChooseStatus.push(item1);
        canChooseStatus.push(item2);
        canChooseStatus.push(item3);
        if(data.curOrderStatus == "已下单"){
            data.curOrderStatusRemake="已下单";
            data.curOrderStatus="PLACEORDER"
        }
        if(data.curOrderStatus == "已预约"){
            data.curOrderStatusRemake="已预约";
            data.curOrderStatus="RESERVATION"
        }
        if(data.curOrderStatus == "已完工"){
            data.curOrderStatusRemake="已完工";
            data.curOrderStatus="COMPLETED"
        }
        // if (data.curOrderStatus == "已下单") {
        //     var item1 = {};
        //     var item2 = {};
        //     item1.name = "已预约";
        //     item1.code = "RESERVATION";
        //     item2.name = "已完工";
        //     item2.code = "COMPLETED";
        //     canChooseStatus.push(item1);
        //     canChooseStatus.push(item2);
        // }
        // if (data.curOrderStatus == "已预约") {
        //     var item1 = {};
        //     item1.name = "已完工";
        //     item1.code = "COMPLETED";
        //     canChooseStatus.push(item1);
        // }
        var win = EUI.Window({
            title: "处理订单【" + data.orderNum + "】【当前状态:" + data.curOrderStatusRemake + "】",
            width: 380,
            height: 500,
            padding: 15,
            items: [{
                xtype: "FormPanel",
                id: "dealOrder",
                padding: 0,
                items: [{
                    xtype: "TextField",
                    title: "ID",
                    labelWidth: 110,
                    name: "id",
                    readonly: true,
                    width: 266,
                    // value: data.id,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "用户姓名",
                    labelWidth: 110,
                    readonly: true,
                    name: "userName",
                    width: 266,
                    // value: data.userName
                }, {
                    xtype: "TextField",
                    title: "用户电话",
                    labelWidth: 110,
                    readonly: true,
                    name: "userPhone",
                    width: 266,
                    // value: data.userPhone
                }, {
                    xtype: "TextField",
                    title: "单号",
                    labelWidth: 110,
                    readonly: true,
                    name: "orderNum",
                    width: 266,
                    // value: data.orderNum,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "下单时间",
                    labelWidth: 110,
                    readonly: true,
                    name: "createTime",
                    width: 266,
                    // value: data.createTime
                }, {
                    xtype: "TextField",
                    title: "openId",
                    labelWidth: 110,
                    readonly: true,
                    name: "openId",
                    width: 266,
                    // value: data.openId,
                    hidden: true
                }, {
                    xtype: "TextArea",
                    title: "地址",
                    labelWidth: 110,
                    readonly: true,
                    name: "address",
                    width: 266,
                    height:40
                    // value: data.address
                }, {
                    xtype: "TextField",
                    title: "品类code",
                    labelWidth: 110,
                    readonly: true,
                    name: "code",
                    width: 266,
                    hidden:true,
                    // value: data.code
                }, {
                    xtype: "TextField",
                    title: "品类",
                    labelWidth: 110,
                    readonly: true,
                    name: "content",
                    width: 266,
                    // value: data.content
                }, {
                    xtype: "TextField",
                    title: "服务类型code",
                    labelWidth: 110,
                    readonly: true,
                    name: "serviceTypeCode",
                    width: 266,
                    hidden:true,
                    // value: data.serviceTypeCode
                }, {
                    xtype: "TextField",
                    title: "服务类型",
                    labelWidth: 110,
                    readonly: true,
                    name: "serviceTypeName",
                    width: 266,
                    // value: data.serviceTypeName
                }, {
                    xtype: "TextField",
                    title: "所属分公司",
                    labelWidth: 110,
                    readonly: true,
                    name: "orgId",
                    width: 266,
                    // value: data.orgId,
                    hidden: true
                }, {
                    xtype: "ComboBox",
                    title: "选择订单状态",
                    width: 266,
                    name: "curOrderStatusRemake",
                    labelWidth: 110,
                    field: ["curOrderStatus"],
                    allowBlank: false,
                    data: canChooseStatus,
                    reader: {
                        name: "name",
                        field: ["code"]
                    }
                }, {
                    xtype: "ComboGrid",
                    title: "选择工程师",
                    name: "engineerRepair.engineerName",
                    // id: "engineerComboId",
                    //async: false,
                    field: ["engineerRepair.id"],
                    listWidth: 400,
                    labelWidth: 110,
                    width: 266,
                    allowBlank: false,
                    editable: true,
                    showSearch: true,
                    onSearch: function (value) {
                        this.grid.localSearch(value);
                    },
                    gridCfg: {
                        url: _ctxPath + "/mobile/engineerRepair/listAllEngineer",
                        loadonce: true,
                        colModel: [{
                            name: "id",
                            index: "id",
                            hidden: true
                        }, {
                            label: "工程师编号",
                            name: "engineerNum",
                            index: "engineerNum"
                        }, {
                            label: "工程师姓名",
                            name: "engineerName",
                            index: "engineerName"
                        }]
                    },
                    reader: {
                        name: "engineerName",
                        field: ["id"]
                    }
                }, {
                    xtype: "TextArea",
                    title: "问题描述",
                    labelWidth: 110,
                    readonly: true,
                    name: "remark",
                    width: 266,
                    // value: data.remark
                }, {
                    xtype: "TextArea",
                    title: "备注",
                    labelWidth: 110,
                    name: "beiZhu",
                    width: 266,
                    // value: data.beiZhu
                }]
            }],
            buttons: [{
                title: "保存",
                selected: true,
                handler: function () {
                    var form = EUI.getCmp("dealOrder");
                    if (!form.isValid()) {
                        return;
                    }
                    var data = form.getFormValue();
                    g.saveOrder(data, win);
                }
            }, {
                title: "取消",
                handler: function () {
                    win.remove();
                }
            }]
        });
        EUI.getCmp("dealOrder").loadData(data);
    },
    dealOrderSecondWind: function (data) {
        var g = this;
        var canChooseStatus = [];
        var item1 = {};
        var item2 = {};
        var item3 = {};
        item1.name = "已下单";
        item1.code = "PLACEORDER";
        item2.name = "已预约";
        item2.code = "RESERVATION";
        item3.name = "已完工";
        item3.code = "COMPLETED";
        canChooseStatus.push(item1);
        canChooseStatus.push(item2);
        canChooseStatus.push(item3);
        if(data.curOrderStatus == "已下单"){
            data.curOrderStatusRemake="已下单";
            data.curOrderStatus="PLACEORDER"
        }
        if(data.curOrderStatus == "已预约"){
            data.curOrderStatusRemake="已预约";
            data.curOrderStatus="RESERVATION"
        }
        if(data.curOrderStatus == "已完工"){
            data.curOrderStatusRemake="已完工";
            data.curOrderStatus="COMPLETED"
        }
        // if (data.curOrderStatus == "已下单") {
        //     var item1 = {};
        //     var item2 = {};
        //     item1.name = "已预约";
        //     item1.code = "RESERVATION";
        //     item2.name = "已完工";
        //     item2.code = "COMPLETED";
        //     canChooseStatus.push(item1);
        //     canChooseStatus.push(item2);
        // }
        // if (data.curOrderStatus == "已预约") {
        //     var item1 = {};
        //     item1.name = "已完工";
        //     item1.code = "COMPLETED";
        //     canChooseStatus.push(item1);
        // }
        //将当前状态值设置为空，不让loadData
        // data.curOrderStatus = "";
        var win = EUI.Window({
            title: "处理订单【" + data.orderNum + "】【当前状态:" + data.curOrderStatusRemake + "】",
            width: 390,
            height: 500,
            padding: 15,
            items: [{
                xtype: "FormPanel",
                id: "dealOrderSecond",
                padding: 0,
                items: [{
                    xtype: "TextField",
                    title: "ID",
                    labelWidth: 110,
                    name: "id",
                    readonly: true,
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "用户姓名",
                    labelWidth: 110,
                    readonly: true,
                    name: "userName",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "用户电话",
                    labelWidth: 110,
                    readonly: true,
                    name: "userPhone",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "单号",
                    labelWidth: 110,
                    readonly: true,
                    name: "orderNum",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "下单时间",
                    labelWidth: 110,
                    readonly: true,
                    name: "createTime",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "openId",
                    labelWidth: 110,
                    readonly: true,
                    name: "openId",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextArea",
                    title: "地址",
                    labelWidth: 110,
                    readonly: true,
                    name: "address",
                    width: 266,
                    height:40
                }, {
                    xtype: "TextField",
                    title: "品类code",
                    labelWidth: 110,
                    readonly: true,
                    name: "code",
                    width: 266,
                    hidden:true
                }, {
                    xtype: "TextField",
                    title: "品类",
                    labelWidth: 110,
                    readonly: true,
                    name: "content",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "服务类型code",
                    labelWidth: 110,
                    readonly: true,
                    name: "serviceTypeCode",
                    width: 266,
                    hidden:true
                }, {
                    xtype: "TextField",
                    title: "服务类型",
                    labelWidth: 110,
                    readonly: true,
                    name: "serviceTypeName",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "所属分公司",
                    labelWidth: 110,
                    readonly: true,
                    name: "orgId",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "ComboBox",
                    title: "选择订单状态",
                    width: 266,
                    name: "curOrderStatusRemake",
                    labelWidth: 110,
                    field: ["curOrderStatus"],
                    allowBlank: false,
                    data: canChooseStatus,
                    reader: {
                        name: "name",
                        field: ["code"]
                    }
                }, {
                    xtype: "ComboGrid",
                    title: "选择工程师",
                    name: "engineerRepair.engineerName",
                    // id: "engineerComboId",
                    //async: false,
                    field: ["engineerRepair.id"],
                    listWidth: 400,
                    width: 266,
                    labelWidth: 110,
                    allowBlank: false,
                    editable: true,
                    showSearch: true,
                    onSearch: function (value) {
                        this.grid.localSearch(value);
                    },
                    gridCfg: {
                        url: _ctxPath + "/mobile/engineerRepair/listAllEngineer",
                        loadonce: true,
                        colModel: [{
                            name: "id",
                            index: "id",
                            hidden: true
                        }, {
                            label: "工程师编号",
                            name: "engineerNum",
                            index: "engineerNum"
                        }, {
                            label: "工程师姓名",
                            name: "engineerName",
                            index: "engineerName"
                        }]
                    },
                    reader: {
                        name: "engineerName",
                        field: ["id"]
                    }
                }/*, {
                 xtype: "TextField",
                 title: "工程师Id",
                 name: "engineerRepair.id",
                 labelWidth: 110,
                 readonly: true,
                 width: 266,
                 value: data["engineerRepair.id"],
                 hidden: true
                 }, {
                 xtype: "TextField",
                 title: "工程师",
                 name: "engineerRepair.engineerName",
                 labelWidth: 110,
                 readonly: true,
                 width: 266,
                 value: data["engineerRepair.engineerName"]
                 }*/, {
                    xtype: "TextArea",
                    title: "问题描述",
                    labelWidth: 110,
                    readonly: true,
                    name: "remark",
                    width: 266
                }, {
                    xtype: "TextArea",
                    title: "备注",
                    labelWidth: 110,
                    name: "beiZhu",
                    width: 266
                }]
            }],
            buttons: [{
                title: "保存",
                selected: true,
                handler: function () {
                    var form = EUI.getCmp("dealOrderSecond");
                    if (!form.isValid()) {
                        return;
                    }
                    var data = form.getFormValue();
                    g.saveOrder(data, win);
                }
            }, {
                title: "取消",
                handler: function () {
                    win.remove();
                }
            }]
        });
        EUI.getCmp("dealOrderSecond").loadData(data);
    },
    lookOrderWind: function (data) {
        var g = this;
        if(data.curOrderStatus == "已下单"){
            data.curOrderStatusRemake="已下单";
            data.curOrderStatus="PLACEORDER"
        }
        if(data.curOrderStatus == "已预约"){
            data.curOrderStatusRemake="已预约";
            data.curOrderStatus="RESERVATION"
        }
        if(data.curOrderStatus == "已完工"){
            data.curOrderStatusRemake="已完工";
            data.curOrderStatus="COMPLETED"
        }
        var win = EUI.Window({
            title: "订单号【" + data.orderNum + "】【当前状态:" + data.curOrderStatusRemake + "】",
            width: 390,
            height: 500,
            padding: 15,
            items: [{
                xtype: "FormPanel",
                id: "lookOrder",
                padding: 0,
                items: [{
                    xtype: "TextField",
                    title: "ID",
                    labelWidth: 110,
                    name: "id",
                    readonly: true,
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "用户姓名",
                    labelWidth: 110,
                    readonly: true,
                    name: "userName",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "用户电话",
                    labelWidth: 110,
                    readonly: true,
                    name: "userPhone",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "单号",
                    labelWidth: 110,
                    readonly: true,
                    name: "orderNum",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "下单时间",
                    labelWidth: 110,
                    readonly: true,
                    name: "createTime",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "openId",
                    labelWidth: 110,
                    readonly: true,
                    name: "openId",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextArea",
                    title: "地址",
                    labelWidth: 110,
                    readonly: true,
                    name: "address",
                    width: 266,
                    height:40
                }, {
                    xtype: "TextField",
                    title: "品类code",
                    labelWidth: 110,
                    readonly: true,
                    name: "code",
                    width: 266,
                    hidden:true
                }, {
                    xtype: "TextField",
                    title: "品类",
                    labelWidth: 110,
                    readonly: true,
                    name: "content",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "服务类型code",
                    labelWidth: 110,
                    readonly: true,
                    name: "serviceTypeCode",
                    width: 266,
                    hidden:true
                }, {
                    xtype: "TextField",
                    title: "服务类型",
                    labelWidth: 110,
                    readonly: true,
                    name: "serviceTypeName",
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "所属分公司",
                    labelWidth: 110,
                    readonly: true,
                    name: "orgId",
                    width: 266,
                    hidden: true
                }, {
                    xtype: "TextField",
                    title: "订单状态",
                    name: "curOrderStatusRemake",
                    labelWidth: 110,
                    readonly: true,
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "工程师",
                    name: "engineerRepair.engineerName",
                    labelWidth: 110,
                    readonly: true,
                    width: 266
                }, {
                    xtype: "TextArea",
                    title: "问题描述",
                    labelWidth: 110,
                    readonly: true,
                    name: "remark",
                    width: 266
                }, {
                    xtype: "TextArea",
                    title: "备注",
                    labelWidth: 110,
                    name: "beiZhu",
                    readonly: true,
                    width: 266
                }]
            }],
            buttons: [{
                title: "关闭",
                handler: function () {
                    win.remove();
                }
            }]
        });
        EUI.getCmp("lookOrder").loadData(data)
    },
    saveOrder: function (data, win) {
        var g = this;
        var myMask = EUI.LoadMask({
            msg: "正在保存，请稍候..."
        });
        EUI.Store({
            url: _ctxPath + "/mobile/order/save",
            params: data,
            success: function (result) {
                myMask.hide();
                EUI.ProcessStatus(result);
                if (result.success) {
                    // EUI.getCmp("gridPanel").refreshGrid();
                    EUI.getCmp("gridPanel").setPostParams({
                        page: g.curPage
                    }, true);
                    win.remove();
                }
            },
            failure: function (result) {
                EUI.ProcessStatus(result);
                myMask.hide();
            }
        });
    },
    initParams: function () {
        var g = this;
        EUI.getCmp("gridPanel").setGridParams({
            page: 1
        });
        EUI.getCmp("gridPanel").setPostParams({
            Q_GE_createTime__Date: g.newStartDay,
            Q_LE_createTime__Date: g.endDay
        }, true);
    },
    handleDate: function () {
        var g = this;
        var changeStartDay = g.startDay.toString();
        var str1 = changeStartDay.substring(0, 4);
        var str2 = changeStartDay.substring(4, 6);
        var str3 = changeStartDay.substring(6, 8);
        g.newStartDay = str1 + "-" + str2 + "-" + str3;
    },
    addOrderWind:function () {
        var g = this;
        var win = EUI.Window({
            title: "新增订单",
            width: 400,
            height: 320,
            padding: 15,
            items: [{
                xtype: "FormPanel",
                id:"addOrderFPanel",
                padding: 0,
                items: [{
                    xtype: "TextField",
                    title: "用户姓名",
                    labelWidth: 110,
                    name: "userName",
                    allowBlank: false,
                    width: 266
                }, {
                    xtype: "TextField",
                    title: "用户电话",
                    labelWidth: 110,
                    name: "userPhone",
                    allowBlank: false,
                    width: 266
                }, {
                    xtype: "TextArea",
                    title: "地址",
                    labelWidth: 110,
                    allowBlank: false,
                    name: "address",
                    width: 266,
                    height:40
                }, {
                    xtype: "ComboBox",
                    title: "服务类型",
                    labelWidth: 110,
                    name: "serviceTypeName",
                    width: 266,
                    field: ["serviceTypeCode"],
                    allowBlank: false,
                    data:g.serviceTypeData,
                    reader: {
                        name: "serviceTypeName",
                        field: ["serviceTypeCode"]
                    },
                    afterSelect:function (data) {
                        EUI.getCmp("pingLeiCom").store.params.code = data.data.serviceTypeCode;
                        EUI.getCmp("pingLeiCom").setValue("");
                    }
                }, {
                    xtype: "ComboBox",
                    title: "品类",
                    id:"pingLeiCom",
                    width: 266,
                    async: true,
                    name: "content",
                    labelWidth: 110,
                    field: ["code"],
                    allowBlank: false,
                    reader: {
                        name: "content",
                        field: ["code"]
                    },
                    loadonce:false,
                    store:{
                        url: _ctxPath + "/basic/productCategories/findByServiceTypeCode",
                        params: {
                            code:null
                        }
                    }
                }, {
                    xtype: "TextArea",
                    title: "问题描述",
                    labelWidth: 110,
                    name: "remark",
                    width: 266
                }]
            }],
            buttons: [{
                title: "保存",
                selected: true,
                handler: function () {
                    var form = EUI.getCmp("addOrderFPanel");
                    if (!form.isValid()) {
                        return;
                    }
                    var data = form.getFormValue();
                    g.saveOrder(data, win);
                }
            }, {
                title: "取消",
                handler: function () {
                    win.remove();
                }
            }]
        });
    },
    getServiceTypeData:function () {
        var g = this;
        var mask = EUI.LoadMask();
        EUI.Store({
            url: _ctxPath + "/basic/productCategoriesServiceType/listAllServiceTypeTree",
            success: function (result) {
                g.handleData(result.data);
                mask.hide();
            }, failure: function (result) {
                mask.hide();
                EUI.ProcessStatus(result);
            }
        });
    },
    handleData:function(data){
        var g = this;
        var serviceType = [];
        for(var i=0; i<data.length;i++){
            var object = {};
            object.serviceTypeCode = data[i].serviceTypeCode;
            object.serviceTypeName = data[i].serviceTypeName;
            serviceType.push(object);
        }
        g.serviceTypeData = serviceType;
    }
});