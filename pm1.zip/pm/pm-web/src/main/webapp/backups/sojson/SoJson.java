package com.jf.weather.sites;


import com.jf.weather.weatherUtil.HttpUtil;
import com.jf.weather.Weather;
import com.jf.weather.weatherUtil.XMLUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SoJson {
    /**
     * 来自那个网站
     */
    public static  String siteName = "soJson";
    /**
     * 对应url
     */
    private static final String url = "http://www.sojson.com/open/api/weather/xml.shtml?city=";

    public static Weather getWeather(String city) {
        String data = HttpUtil.getStringData(url, city);
        if (data != null) {
            //XML字符串转数组使用了dom4j架包
            Map<String, Object> map = null;
            try {
                map = XMLUtil.xml2Map(data);
            } catch (Exception e) {
                System.out.println("XML格式解析异常" + e);
                e.printStackTrace();
            }
            try {
                if (null==map.get("error")) {
                    /**
                     * 得到所有所需要的数据
                     */
                    String location = (String) map.get("city");
                    ArrayList<String> datas = (ArrayList<String>) map.get("date");
                    ArrayList<String> highs = (ArrayList<String>) map.get("high");
                    ArrayList<String> lows = (ArrayList<String>) map.get("low");
                    ArrayList<String> tmps  = new ArrayList<>();
                    for (int i = 0; i < highs.size(); i++) {
                            //处理温度计算平均温度处理格式
                            String s = highs.get(i);
                            String substring = s.substring(s.indexOf(" ") + 1, s.indexOf("℃"));
                            double high = Double.parseDouble(substring);
                                s = lows.get(i);
                                substring = s.substring(s.indexOf(" ") + 1, s.indexOf("℃"));
                            double low = Double.parseDouble(substring);
                            tmps.add((high + low) / 2 + "℃");
                        }
                    ArrayList<String> allFengxiang = (ArrayList<String>) map.get("fengxiang");
                    ArrayList<String> allConds = (ArrayList<String>) map.get("type");
                    allFengxiang.remove(0);
                    ArrayList<String> fengxiangs = new ArrayList<>();
                    ArrayList<String> conds = new ArrayList<>();
                    for (int i=0;i<allConds.size()/2;i++){
                        conds.add(allConds.get(2*i));
                        fengxiangs.add(allFengxiang.get(2*i));
                    }
                    List<Weather> future = new ArrayList<>();
                    for (int i=1;i<3;i++){
                        String date = datas.get(i);
                        String tmp=""+tmps.get(i);
                        String fengxiang = fengxiangs.get(i);//风向
                        String cond = conds.get(i);//天气状况，如：小雨，晴等
                        future.add(new Weather(date,tmp,fengxiang,cond));
                    }
                    return new Weather(siteName,location,datas.get(0),tmps.get(0),fengxiangs.get(0),conds.get(0),future);
                }
            } catch (RuntimeException e) {
                return null;
            }
        }
        return null;
    }
}
