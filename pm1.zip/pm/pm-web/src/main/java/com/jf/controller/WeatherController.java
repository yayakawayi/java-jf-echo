package com.jf.controller;

import com.jf.weather.Weather;
import com.jf.weather.weatherUtil.WeatherUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@Controller
@RequestMapping("/weather")
public class WeatherController {
    /**
     * 得到天气数据
     */
    @ResponseBody
    @RequestMapping("/getWeather")
    public Weather getWeather(String location) {
        return WeatherUtil.getWeather(location);
    }
    /**
     * 显示地图
     */
    @RequestMapping("/showMap")
    public String showMap() {
        return "map/AMap";
    }
    /**
     * 抓取天气网站管理页
     */
    @RequestMapping("/siteView")
    public String showSite() {
        return "site/SiteView";
    }
    /**
     * 得到正在使用的网站
     */
    @ResponseBody
    @RequestMapping("/getSites")
    public String[] getSites() {
        return WeatherUtil.getSites();
    }

    @RequestMapping("/setSites")
    public void setSites(String sites) {
        WeatherUtil.setSites(sites);
    }

    @RequestMapping("/setSitesSort")
    public void setSitesSort(String sites) {
        WeatherUtil.setSitesSort(sites);
    }

    @ResponseBody
    @RequestMapping("/getSitesSort")
    public String[] getSitesSort() {
        return WeatherUtil.getSitesSort();
    }
    /**
     * 得到location的对应经纬度
     */
    @ResponseBody
    @RequestMapping("/getLngLat")
    public Map<String, String> page8(String location) {
        return WeatherUtil.getLngLat(location);
    }
}
